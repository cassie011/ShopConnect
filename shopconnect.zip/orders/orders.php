<?php
require_once "../includes/auth.php";
require_once "../config/database.php";
require_login();

$userId = $_SESSION["user_id"];

$stmt = $conn->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC");
$stmt->bind_param("i", $userId);
$stmt->execute();
$orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

include "../includes/header.php";
?>

<h2>My Orders</h2>

<?php if (isset($_GET["placed"])): ?>
    <div class="message success">
        Thank you! Your order #<?= (int) $_GET["placed"] ?> has been placed and is now Pending.
        <?php if (($_GET["email"] ?? "") === "sent"): ?>
            <br>A confirmation email has been sent to you.
        <?php elseif (($_GET["email"] ?? "") === "failed"): ?>
            <br>We could not send the confirmation email, but your order is saved.
        <?php endif; ?>
    </div>
<?php endif; ?>

<?php if (empty($orders)): ?>
    <p>You have no orders yet.</p>
    <a class="btn" href="../shop/index.php">Start Shopping</a>
<?php endif; ?>

<?php foreach ($orders as $order): ?>
    <?php
    $stmt = $conn->prepare(
        "SELECT oi.quantity, oi.price, p.name
         FROM order_items oi JOIN products p ON p.id = oi.product_id
         WHERE oi.order_id = ?"
    );
    $stmt->bind_param("i", $order["id"]);
    $stmt->execute();
    $orderItems = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    ?>
    <div class="order-card">
        <div class="order-head">
            <strong>Order #<?= $order["id"] ?></strong>
            <span class="badge badge-<?= strtolower($order["status"]) ?>"><?= $order["status"] ?></span>
            <span class="muted"><?= date("M d, Y h:i A", strtotime($order["created_at"])) ?></span>
        </div>
        <table class="table">
            <tr><th>Product</th><th>Qty</th><th>Price</th><th>Subtotal</th></tr>
            <?php foreach ($orderItems as $item): ?>
                <tr>
                    <td><?= htmlspecialchars($item["name"]) ?></td>
                    <td><?= $item["quantity"] ?></td>
                    <td>₱<?= number_format($item["price"], 2) ?></td>
                    <td>₱<?= number_format($item["price"] * $item["quantity"], 2) ?></td>
                </tr>
            <?php endforeach; ?>
            <tr class="total-row">
                <td colspan="3">Total</td>
                <td>₱<?= number_format($order["total_amount"], 2) ?></td>
            </tr>
        </table>
    </div>
<?php endforeach; ?>

<?php include "../includes/footer.php"; ?>
