@echo off
REM Right-click this file -> "Run as administrator".
REM It lets other devices on your home Wi-Fi reach the ShopConnect chat server (port 8080).
netsh advfirewall firewall delete rule name="ShopConnect Chat" >nul 2>&1
netsh advfirewall firewall add rule name="ShopConnect Chat" dir=in action=allow protocol=TCP localport=8080 profile=private
echo.
echo Done. If you see "Ok." above, the firewall rule was added.
pause
