SHOPCONNECT - NGROK (share over the internet)
=============================================
1. Copy this folder over your old shopconnect folder (keep your config files).
2. Paste apache-websocket-proxy.conf into the bottom of C:\xampp\apache\conf\httpd.conf, restart Apache.
3. Restart the chat server.
4. Run ngrok:  ngrok http 80
5. Open the https://...ngrok-free.app/shopconnect/ address on any device.
