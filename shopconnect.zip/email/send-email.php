<?php
// Email helper for ShopConnect (uses PHPMailer + Gmail SMTP).
// Other pages do:  require_once "../email/send-email.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as MailException;

// Load PHPMailer: Composer's autoloader if it exists, otherwise the files in lib/PHPMailer/
function load_phpmailer()
{
    if (class_exists("PHPMailer\\PHPMailer\\PHPMailer")) {
        return true;
    }
    $autoload = __DIR__ . "/../vendor/autoload.php";
    if (file_exists($autoload)) {
        require_once $autoload;
        if (class_exists("PHPMailer\\PHPMailer\\PHPMailer")) {
            return true;
        }
    }
    $folder = __DIR__ . "/../lib/PHPMailer/";
    if (file_exists($folder . "PHPMailer.php") && file_exists($folder . "SMTP.php") && file_exists($folder . "Exception.php")) {
        require_once $folder . "Exception.php";
        require_once $folder . "PHPMailer.php";
        require_once $folder . "SMTP.php";
        return true;
    }
    return false;
}

// Sends one plain-text email. Returns [true, ""] on success or [false, "reason"] on failure.
function send_mail($toEmail, $toName, $subject, $body)
{
    require_once __DIR__ . "/../config/mail.php";

    if (!load_phpmailer()) {
        return [false, "PHPMailer is not installed. Copy its files into lib/PHPMailer/ (see the Stage 5 guide)."];
    }
    if (MAIL_USERNAME === "your.email@gmail.com") {
        return [false, "Email is not set up yet. Open config/mail.php and add your Gmail and App Password."];
    }

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->Host       = "smtp.gmail.com";
        $mail->SMTPAuth   = true;
        $mail->Username   = MAIL_USERNAME;
        $mail->Password   = str_replace(" ", "", MAIL_APP_PASSWORD);   // spaces are not part of the password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        $mail->Timeout    = 15;
        $mail->CharSet    = "UTF-8";

        $mail->setFrom(MAIL_USERNAME, MAIL_FROM_NAME);
        $mail->addAddress($toEmail, $toName);
        $mail->Subject = $subject;
        $mail->Body    = $body;
        $mail->isHTML(false);

        $mail->send();
        return [true, ""];
    } catch (MailException $e) {
        error_log("ShopConnect mail error: " . $mail->ErrorInfo);
        return [false, $mail->ErrorInfo];
    }
}

// Email sent after a customer places an order
function send_order_confirmation($orderId, $customerName, $customerEmail, $total)
{
    $firstName = explode(" ", trim($customerName))[0];

    $body = "Hello " . $firstName . ",\n\n"
          . "Thank you for your order from ShopConnect.\n\n"
          . "Order Number: #" . $orderId . "\n\n"
          . "Your order has been received and is currently being processed.\n\n"
          . "Total: ₱" . number_format($total, 2) . "\n\n"
          . "Thank you for shopping with us!\n\n"
          . "ShopConnect";

    return send_mail($customerEmail, $customerName, "ShopConnect Order Confirmation", $body);
}

// Email sent when a new account is created
function send_welcome_email($name, $email)
{
    $firstName = explode(" ", trim($name))[0];

    $body = "Hello " . $firstName . ",\n\n"
          . "Welcome to ShopConnect! Your account has been created with this email address.\n\n"
          . "If you did not create this account, you can ignore this email.\n\n"
          . "ShopConnect";

    return send_mail($email, $name, "Welcome to ShopConnect", $body);
}
