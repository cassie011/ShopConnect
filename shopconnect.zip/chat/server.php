<?php
// ShopConnect chat server (WebSocket).
// Start it from the command line:   php chat/server.php
// Keep it running while you use the chat.

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use Ratchet\Server\IoServer;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;

error_reporting(E_ALL & ~E_DEPRECATED);   // hide harmless "deprecated" notices from libraries

if (PHP_SAPI !== "cli") {
    die("This file must be started from the command line, not opened in the browser.");
}
if (!file_exists(__DIR__ . "/../vendor/autoload.php")) {
    die("Ratchet is not installed yet.\nOpen a terminal in the shopconnect folder and run:  composer install\n");
}

require __DIR__ . "/../vendor/autoload.php";
require __DIR__ . "/../config/database.php";     // gives us $host, $user, $pass, $dbname
$dbSettings = [$host, $user, $pass, $dbname];
$conn->close();                                  // the chat server opens its own short connections
require __DIR__ . "/../includes/chat_token.php"; // also loads config/chat.php


class ShopChat implements MessageComponentInterface
{
    private $clients;   // everybody connected: connection => info
    private $db;
    private $calls = [];   // calls happening now: customer id => call info

    public function __construct(array $db)
    {
        $this->clients = new SplObjectStorage();
        $this->db = $db;
    }

    // A new browser connected. It must send its ticket (login) before doing anything.
    public function onOpen(ConnectionInterface $conn)
    {
        $this->clients->attach($conn, ["auth" => false]);
    }

    public function onMessage(ConnectionInterface $from, $msg)
    {
        $data = json_decode($msg, true);
        if (!is_array($data) || !isset($data["type"])) {
            return;
        }

        // Step 1: the browser proves who it is
        if ($data["type"] === "auth") {
            $user = verify_chat_token($data["token"] ?? "");
            if (!$user) {
                $this->send($from, ["type" => "error", "fatal" => true,
                    "message" => "Your login expired. Please refresh the page."]);
                $from->close();
                return;
            }
            $this->clients[$from] = [
                "auth" => true,
                "id"   => (int) $user["uid"],
                "name" => $user["name"],
                "role" => $user["role"] === "admin" ? "admin" : "customer",
            ];
            echo "Connected: " . $user["name"] . " (" . $user["role"] . ")\n";
            $this->send($from, ["type" => "auth_ok"]);
            return;
        }

        $info = $this->clients[$from];
        if (empty($info["auth"])) {
            return;   // ignore anyone who has not logged in
        }

        switch ($data["type"]) {
            case "chat":
                $this->handleChat($from, $info, $data);
                break;

            // Voice / video calls (WebRTC). The server only passes the "signals" along;
            // the audio and video travel directly between the two browsers.
            case "call_invite":
                $this->handleCallInvite($from, $info, $data);
                break;
            case "call_accept":
                $this->handleCallAccept($from, $info, $data);
                break;
            case "call_reject":
                $this->handleCallReject($from, $info, $data);
                break;
            case "call_end":
                $this->handleCallEnd($from, $info, $data);
                break;
            case "rtc_offer":
            case "rtc_answer":
            case "rtc_ice":
                $this->relaySignal($from, $info, $data);
                break;
        }
    }

    // Save a chat message and deliver it to the right people
    private function handleChat(ConnectionInterface $from, array $info, array $data)
    {
        $text = trim((string) ($data["message"] ?? ""));
        if ($text === "") {
            return;
        }
        $text = mb_substr($text, 0, 1000);

        $db = null;
        try {
            [$h, $u, $p, $d] = $this->db;
            $db = new mysqli($h, $u, $p, $d);
            $db->set_charset("utf8mb4");

            if ($info["role"] === "admin") {
                // Admin replies to a customer
                $customerId = (int) ($data["to"] ?? 0);
                $stmt = $db->prepare("SELECT id FROM users WHERE id = ? AND role = 'customer'");
                $stmt->bind_param("i", $customerId);
                $stmt->execute();
                if (!$stmt->get_result()->fetch_assoc()) {
                    throw new Exception("That customer was not found.");
                }
                $senderId = $info["id"];
                $receiverId = $customerId;
            } else {
                // Customer writes to the shop (we use the first admin account as the receiver)
                $customerId = $info["id"];
                $admin = $db->query("SELECT id FROM users WHERE role = 'admin' ORDER BY id LIMIT 1")->fetch_assoc();
                if (!$admin) {
                    throw new Exception("The shop has no admin account yet.");
                }
                $senderId = $customerId;
                $receiverId = (int) $admin["id"];
            }

            // Save the message in MySQL
            $stmt = $db->prepare("INSERT INTO messages (sender_id, receiver_id, message) VALUES (?, ?, ?)");
            $stmt->bind_param("iis", $senderId, $receiverId, $text);
            $stmt->execute();
            $messageId = $db->insert_id;

            $stmt = $db->prepare("SELECT created_at FROM messages WHERE id = ?");
            $stmt->bind_param("i", $messageId);
            $stmt->execute();
            $createdAt = $stmt->get_result()->fetch_assoc()["created_at"];

        } catch (mysqli_sql_exception $e) {
            echo "Database error: " . $e->getMessage() . "\n";
            $this->send($from, ["type" => "error", "message" => "Message not sent. Please try again."]);
            return;
        } catch (Exception $e) {
            $this->send($from, ["type" => "error", "message" => $e->getMessage()]);
            return;
        } finally {
            if ($db) {
                $db->close();
            }
        }

        $payload = [
            "type"        => "chat",
            "id"          => $messageId,
            "customer_id" => $customerId,
            "sender_id"   => $senderId,
            "sender_name" => $info["name"],
            "sender_role" => $info["role"],
            "message"     => $text,
            "created_at"  => $createdAt,
        ];

        // Deliver to every admin, and to that customer (all of their open tabs)
        foreach ($this->clients as $conn) {
            $c = $this->clients[$conn];
            if (empty($c["auth"])) {
                continue;
            }
            if ($c["role"] === "admin" || $c["id"] === $customerId) {
                $this->send($conn, $payload);
            }
        }
    }

    // ---------------------------------------------------------
    // Voice / video call helpers
    // ---------------------------------------------------------

    // All connected browsers with a role ("admin" or "customer"), optionally one customer only
    private function connectionsOf($role, $customerId = null)
    {
        $found = [];
        foreach ($this->clients as $conn) {
            $c = $this->clients[$conn];
            if (empty($c["auth"]) || $c["role"] !== $role) {
                continue;
            }
            if ($customerId !== null && $c["id"] !== $customerId) {
                continue;
            }
            $found[] = $conn;
        }
        return $found;
    }

    // Every call belongs to one customer. Which customer is it about?
    private function customerIdFor(array $info, array $data)
    {
        if ($info["role"] === "admin") {
            return (int) ($data["customer_id"] ?? $data["to"] ?? 0);
        }
        return $info["id"];
    }

    private function handleCallInvite(ConnectionInterface $from, array $info, array $data)
    {
        $media = (($data["media"] ?? "") === "video") ? "video" : "voice";
        $customerId = $this->customerIdFor($info, $data);
        if ($customerId <= 0) {
            return;
        }

        if (isset($this->calls[$customerId])) {
            $this->send($from, ["type" => "call_busy"]);
            return;
        }

        if ($info["role"] === "customer") {
            // Customer calls the shop: ring every admin that is online
            $targets = $this->connectionsOf("admin");
            if (empty($targets)) {
                $this->send($from, ["type" => "call_unavailable",
                    "message" => "Support is offline right now. Please leave us a chat message."]);
                return;
            }
            $this->calls[$customerId] = ["media" => $media, "caller" => "customer",
                "customer" => $from, "admin" => null, "state" => "ringing"];
            $ring = ["type" => "call_invite", "customer_id" => $customerId,
                "name" => $info["name"], "media" => $media];
        } else {
            // Admin calls a customer: ring that customer's open pages
            $targets = $this->connectionsOf("customer", $customerId);
            if (empty($targets)) {
                $this->send($from, ["type" => "call_unavailable",
                    "message" => "That customer is not online right now."]);
                return;
            }
            $this->calls[$customerId] = ["media" => $media, "caller" => "admin",
                "customer" => null, "admin" => $from, "state" => "ringing"];
            $ring = ["type" => "call_invite", "customer_id" => $customerId,
                "name" => "ShopConnect Support", "media" => $media];
        }

        foreach ($targets as $target) {
            $this->send($target, $ring);
        }
        echo "Call ringing (" . $media . "): " . $info["name"] . " is calling\n";
    }

    // Is this person the one being called (not the one who started the call)?
    private function isCallee(array $info, array $call, $customerId)
    {
        if ($call["caller"] === "customer") {
            return $info["role"] === "admin";
        }
        return $info["role"] === "customer" && $info["id"] === $customerId;
    }

    private function handleCallAccept(ConnectionInterface $from, array $info, array $data)
    {
        $customerId = $this->customerIdFor($info, $data);
        $call = $this->calls[$customerId] ?? null;
        if (!$call || $call["state"] !== "ringing" || !$this->isCallee($info, $call, $customerId)) {
            return;
        }

        if ($call["caller"] === "customer") {
            $call["admin"] = $from;
            $caller = $call["customer"];
            $others = $this->connectionsOf("admin");
        } else {
            $call["customer"] = $from;
            $caller = $call["admin"];
            $others = $this->connectionsOf("customer", $customerId);
        }
        $call["state"] = "active";
        $this->calls[$customerId] = $call;

        // Stop the phone ringing on every other page
        foreach ($others as $other) {
            if ($other !== $from) {
                $this->send($other, ["type" => "call_taken", "customer_id" => $customerId]);
            }
        }
        // Tell the caller they can start the connection now
        $this->send($caller, ["type" => "call_accept", "customer_id" => $customerId, "media" => $call["media"]]);
        echo "Call accepted: " . $info["name"] . "\n";
    }

    private function handleCallReject(ConnectionInterface $from, array $info, array $data)
    {
        $customerId = $this->customerIdFor($info, $data);
        $call = $this->calls[$customerId] ?? null;
        if (!$call || $call["state"] !== "ringing" || !$this->isCallee($info, $call, $customerId)) {
            return;
        }

        $reason = (($data["reason"] ?? "") === "busy") ? "busy" : "declined";
        $caller = ($call["caller"] === "customer") ? $call["customer"] : $call["admin"];
        $this->send($caller, ["type" => "call_rejected", "customer_id" => $customerId, "reason" => $reason]);

        // Stop ringing everywhere else too
        $others = ($call["caller"] === "customer")
            ? $this->connectionsOf("admin")
            : $this->connectionsOf("customer", $customerId);
        foreach ($others as $other) {
            if ($other !== $from) {
                $this->send($other, ["type" => "call_end", "customer_id" => $customerId]);
            }
        }
        unset($this->calls[$customerId]);
    }

    private function handleCallEnd(ConnectionInterface $from, array $info, array $data)
    {
        $customerId = $this->customerIdFor($info, $data);
        $call = $this->calls[$customerId] ?? null;
        if (!$call) {
            return;
        }
        // Only the two people in the call may end it
        if ($from !== $call["customer"] && $from !== $call["admin"]) {
            return;
        }
        $this->terminateCall($customerId, $call, $from);
    }

    // End a call and tell the other side
    private function terminateCall($customerId, array $call, $initiator)
    {
        if ($call["state"] === "active") {
            $other = ($initiator === $call["customer"]) ? $call["admin"] : $call["customer"];
            if ($other) {
                $this->send($other, ["type" => "call_end", "customer_id" => $customerId]);
            }
        } else {
            // Still ringing: stop the ringing on the called side
            $targets = ($call["caller"] === "customer")
                ? $this->connectionsOf("admin")
                : $this->connectionsOf("customer", $customerId);
            foreach ($targets as $target) {
                $this->send($target, ["type" => "call_end", "customer_id" => $customerId]);
            }
        }
        unset($this->calls[$customerId]);
    }

    // Pass WebRTC "offer", "answer" and "ice" messages to the other person in the call
    private function relaySignal(ConnectionInterface $from, array $info, array $data)
    {
        $customerId = $this->customerIdFor($info, $data);
        $call = $this->calls[$customerId] ?? null;
        if (!$call || $call["state"] !== "active") {
            return;
        }

        if ($from === $call["customer"]) {
            $to = $call["admin"];
        } elseif ($from === $call["admin"]) {
            $to = $call["customer"];
        } else {
            return;   // not part of this call
        }
        if (!$to) {
            return;
        }

        $out = ["type" => $data["type"], "customer_id" => $customerId];
        foreach (["sdp", "candidate"] as $key) {
            if (isset($data[$key])) {
                $out[$key] = $data[$key];
            }
        }
        $this->send($to, $out);
    }

    private function send(ConnectionInterface $conn, array $data)
    {
        $conn->send(json_encode($data, JSON_UNESCAPED_UNICODE));
    }

    public function onClose(ConnectionInterface $conn)
    {
        $this->clients->detach($conn);

        // If this browser was in a call, tell the other side the call is over
        foreach ($this->calls as $customerId => $call) {
            if ($conn === $call["customer"] || $conn === $call["admin"]) {
                $this->terminateCall($customerId, $call, $conn);
            }
        }
    }

    public function onError(ConnectionInterface $conn, \Exception $e)
    {
        echo "Error: " . $e->getMessage() . "\n";
        $conn->close();
    }
}

// Start listening. "0.0.0.0" lets other devices on your Wi-Fi (like a phone) connect.
// (Use "127.0.0.1" if you want only this computer to connect.)
$bindAddress = defined("CHAT_BIND") ? CHAT_BIND : "0.0.0.0";

$server = IoServer::factory(
    new HttpServer(new WsServer(new ShopChat($dbSettings))),
    CHAT_PORT,
    $bindAddress
);

echo "ShopConnect chat server is running on port " . CHAT_PORT . ".\n";
echo "Keep this window open. Press Ctrl+C to stop.\n\n";
$server->run();
