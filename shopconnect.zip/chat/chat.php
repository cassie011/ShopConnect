<?php
require_once "../includes/auth.php";
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/chat_token.php";
require_login();

// Admins use their own chat page
if (($_SESSION["role"] ?? "") === "admin") {
    header("Location: ../admin/chat.php");
    exit;
}

$userId = $_SESSION["user_id"];

// Load the last 200 messages of this customer's conversation
$stmt = $conn->prepare(
    "SELECT m.id, m.sender_id, m.message, m.created_at, u.name AS sender_name, u.role AS sender_role
     FROM messages m JOIN users u ON u.id = m.sender_id
     WHERE m.sender_id = ? OR m.receiver_id = ?
     ORDER BY m.id DESC LIMIT 200"
);
$stmt->bind_param("ii", $userId, $userId);
$stmt->execute();
$messages = array_reverse($stmt->get_result()->fetch_all(MYSQLI_ASSOC));

$token = make_chat_token($userId, $_SESSION["user_name"], "customer");

include "../includes/header.php";
?>

<h2>Customer Support Chat</h2>

<div class="chat-card" id="chat-app"
     data-ws-url="<?= htmlspecialchars(chat_ws_url()) ?>"
     data-ice="<?= htmlspecialchars(json_encode(chat_ice_servers())) ?>"
     data-token="<?= htmlspecialchars($token) ?>"
     data-role="customer"
     data-me="<?= (int) $userId ?>"
     data-customer="<?= (int) $userId ?>">

    <div class="chat-header">
        <div class="avatar">🛍️</div>
        <div>
            <strong>ShopConnect Support</strong><br>
            <small id="chat-status" class="status">Connecting...</small>
        </div>
        <div class="call-buttons">
            <button type="button" id="btn-voice-call" >📞 Voice Call</button>
            <button type="button" id="btn-video-call" >🎥 Video Call</button>
        </div>
    </div>

    <div class="chat-messages" id="chat-messages">
        <?php if (empty($messages)): ?>
            <p class="chat-empty" id="chat-empty">No messages yet. Say hello! 👋</p>
        <?php endif; ?>
        <?php foreach ($messages as $m) { render_chat_message($m, $userId, "customer"); } ?>
    </div>

    <form id="chat-form" class="chat-form" autocomplete="off">
        <input type="text" id="chat-input" placeholder="Type your message..." maxlength="1000">
        <button type="submit">Send</button>
    </form>
</div>

<script src="<?= $base ?>/js/chat.js"></script>
<script src="<?= $base ?>/js/call.js"></script>

<?php include "../includes/footer.php"; ?>
