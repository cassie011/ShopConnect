<?php
// Helpers that find out HOW the visitor reached the website
// (http://localhost, http://192.168.x.x, or https://something.ngrok-free.app).

// Is the visitor using HTTPS? (ngrok adds the X-Forwarded-Proto header)
function request_is_https()
{
    if (!empty($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] !== "off") {
        return true;
    }
    return ($_SERVER["HTTP_X_FORWARDED_PROTO"] ?? "") === "https";
}

// The host name the visitor typed, like "localhost" or "abc.ngrok-free.app"
function request_host()
{
    $host = $_SERVER["HTTP_HOST"] ?? "localhost";
    return preg_match('/^[A-Za-z0-9.\-:\[\]]+$/', $host) ? $host : "localhost";
}

// Example: "https://abc.ngrok-free.app"
function request_origin()
{
    return (request_is_https() ? "https" : "http") . "://" . request_host();
}

// Where Google should send the user back to after login.
// It follows the address being used, so it works on localhost AND through ngrok.
// (Every address you use must also be added in Google Cloud Console.)
function google_redirect_uri()
{
    return request_origin() . "/shopconnect/auth/google-callback.php";
}
