<?php
// Helper functions to protect pages.
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Only logged-in users can open the page
function require_login()
{
    if (!isset($_SESSION["user_id"])) {
        header("Location: /shopconnect/auth/login.php");
        exit;
    }
}

// Only the admin can open the page
function require_admin()
{
    require_login();
    if (($_SESSION["role"] ?? "") !== "admin") {
        http_response_code(403);
        die("Access denied. Admins only. <a href='/shopconnect/shop/index.php'>Back to shop</a>");
    }
}
