<?php
// A "chat ticket" proves to the chat server who the user is.
// The website (which knows who is logged in) creates the ticket,
// and the chat server checks its signature. Nobody can fake it without CHAT_SECRET.
require_once __DIR__ . "/../config/chat.php";
require_once __DIR__ . "/url_helper.php";

// The address the browser should use to reach the chat server.
//  - On a normal page (http://localhost or http://192.168.x.x) it connects straight to port 8080.
//  - On a secure page (https, for example through ngrok) the browser is only allowed to use "wss",
//    so it connects through the web server (Apache), which forwards to the chat server.
function chat_ws_url()
{
    if (request_is_https()) {
        return "wss://" . request_host() . "/shopconnect-ws";
    }
    $host = preg_replace('/:\d+$/', "", request_host());   // remove the web port (like :80)
    return "ws://" . $host . ":" . CHAT_PORT;
}

// Servers that help two browsers find each other for voice/video calls.
// STUN is free. A TURN server (optional) helps when two devices are on different networks.
function chat_ice_servers()
{
    $servers = [["urls" => "stun:stun.l.google.com:19302"]];

    if (defined("CHAT_TURN_URL") && CHAT_TURN_URL !== "") {
        $servers[] = [
            "urls"       => array_map("trim", explode(",", CHAT_TURN_URL)),
            "username"   => defined("CHAT_TURN_USER") ? CHAT_TURN_USER : "",
            "credential" => defined("CHAT_TURN_PASS") ? CHAT_TURN_PASS : "",
        ];
    }
    return $servers;
}

function chat_b64($text)
{
    return rtrim(strtr(base64_encode($text), "+/", "-_"), "=");
}

function chat_unb64($text)
{
    return base64_decode(strtr($text, "-_", "+/"));
}

// Website side: create a ticket that is valid for 8 hours
function make_chat_token($userId, $name, $role)
{
    $payload = chat_b64(json_encode([
        "uid"  => (int) $userId,
        "name" => $name,
        "role" => $role,
        "exp"  => time() + 8 * 3600,
    ]));
    return $payload . "." . hash_hmac("sha256", $payload, CHAT_SECRET);
}

// Chat server side: check a ticket. Returns the user data, or null if it is fake/expired.
function verify_chat_token($token)
{
    $parts = explode(".", (string) $token);
    if (count($parts) !== 2) {
        return null;
    }
    [$payload, $signature] = $parts;

    if (!hash_equals(hash_hmac("sha256", $payload, CHAT_SECRET), $signature)) {
        return null;
    }
    $data = json_decode(chat_unb64($payload), true);
    if (!is_array($data) || ($data["exp"] ?? 0) < time()) {
        return null;
    }
    return $data;
}
