<?php
// Start the session once (sessions remember who is logged in)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . "/../config/database.php";

// $base is the URL path of the project folder
$base = "/shopconnect";
$loggedIn = isset($_SESSION["user_id"]);
$isAdmin = ($_SESSION["role"] ?? "") === "admin";

// Number shown on the cart badge
$navCartCount = 0;
if ($loggedIn) {
    $navStmt = $conn->prepare("SELECT COALESCE(SUM(quantity), 0) FROM cart WHERE user_id = ?");
    $navStmt->bind_param("i", $_SESSION["user_id"]);
    $navStmt->execute();
    $navStmt->bind_result($navCartCount);
    $navStmt->fetch();
    $navStmt->close();
}

// Which menu item is the current page? (it gets highlighted)
$navPage = basename($_SERVER["PHP_SELF"]);
$navDir  = basename(dirname($_SERVER["PHP_SELF"]));
$navShop    = ($navDir === "shop" && in_array($navPage, ["index.php", "product.php"]));
$navCart    = ($navDir === "shop" && in_array($navPage, ["cart.php", "checkout.php"]));
$navOrders  = ($navDir === "orders");
$navAccount = ($navPage === "account.php");
$navAdmin   = ($navDir === "admin" && $navPage !== "chat.php");
$navChat    = ($navDir === "chat" || ($navDir === "admin" && $navPage === "chat.php"));
$chatUrl    = $base . ($isAdmin ? "/admin/chat.php" : "/chat/chat.php");
$navLogin   = in_array($navPage, ["login.php", "register.php"]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ShopConnect</title>
    <link rel="icon" type="image/png" href="<?= $base ?>/assets/favicon.png">
    <link rel="stylesheet" href="<?= $base ?>/css/style.css">
</head>
<body>

<!-- This hidden checkbox opens/closes the menu on phones (no JavaScript needed) -->
<input type="checkbox" id="nav-toggle" class="nav-toggle">

<div class="app">

    <label for="nav-toggle" class="menu-btn" aria-label="Open menu">☰</label>
    <label for="nav-toggle" class="overlay"></label>

    <aside class="sidebar">
        <a href="<?= $base ?>/shop/index.php" class="sidebar-logo">
            <img src="<?= $base ?>/assets/shopconnect-logo.png" alt="ShopConnect">
        </a>

        <nav class="side-nav">
            <a href="<?= $base ?>/shop/index.php" class="<?= $navShop ? "active" : "" ?>">
                <span class="icon">🛍️</span> Shop
            </a>
            <a href="<?= $base ?>/shop/cart.php" class="<?= $navCart ? "active" : "" ?>">
                <span class="icon">🛒</span> Cart
                <?php if ($navCartCount > 0): ?>
                    <span class="cart-badge"><?= (int) $navCartCount ?></span>
                <?php endif; ?>
            </a>
            <a href="<?= $base ?>/orders/orders.php" class="<?= $navOrders ? "active" : "" ?>">
                <span class="icon">📦</span> My Orders
            </a>
            <a href="<?= $chatUrl ?>" class="<?= $navChat ? "active" : "" ?>">
                <span class="icon">💬</span> <?= $isAdmin ? "Customer Chats" : "Support Chat" ?>
            </a>
            <a href="<?= $base ?>/auth/account.php" class="<?= $navAccount ? "active" : "" ?>">
                <span class="icon">👤</span> My Account
            </a>
            <?php if ($isAdmin): ?>
                <a href="<?= $base ?>/admin/dashboard.php" class="<?= $navAdmin ? "active" : "" ?>">
                    <span class="icon">⚙️</span> Admin Panel
                </a>
            <?php endif; ?>
        </nav>

        <div class="sidebar-bottom">
            <?php if ($loggedIn): ?>
                <div class="user-card">
                    <div class="avatar"><?= htmlspecialchars(strtoupper(mb_substr($_SESSION["user_name"], 0, 1))) ?></div>
                    <div class="user-info">
                        <strong><?= htmlspecialchars($_SESSION["user_name"]) ?></strong>
                        <small><?= $isAdmin ? "Administrator" : "Customer" ?></small>
                    </div>
                </div>
                <a href="<?= $base ?>/auth/logout.php" class="logout-link">🚪 Logout</a>
            <?php else: ?>
                <a href="<?= $base ?>/auth/login.php" class="login-link <?= $navLogin ? "active" : "" ?>">🔑 Login</a>
            <?php endif; ?>
        </div>
    </aside>

    <div class="content">
        <main class="container">
