        </main>

        <footer class="site-footer">
            <p>&copy; <?= date("Y") ?> ShopConnect. School project.</p>
        </footer>
    </div>
</div>

</body>
</html>
