<?php
// Saves an uploaded product image into the images/ folder.
// Returns [filename, errorMessage]. If no file was chosen: [null, null].
function save_product_image($file)
{
    if (!isset($file) || $file["error"] === UPLOAD_ERR_NO_FILE) {
        return [null, null];
    }
    if ($file["error"] !== UPLOAD_ERR_OK) {
        return [null, "Image upload failed. Try a smaller image."];
    }
    if ($file["size"] > 2 * 1024 * 1024) {
        return [null, "Image must be 2 MB or smaller."];
    }

    $allowed = [
        "image/jpeg" => "jpg",
        "image/png"  => "png",
        "image/gif"  => "gif",
        "image/webp" => "webp",
    ];

    // getimagesize() checks the file is really an image
    $info = @getimagesize($file["tmp_name"]);
    if ($info === false || !isset($allowed[$info["mime"]])) {
        return [null, "Only JPG, PNG, GIF or WEBP images are allowed."];
    }

    $filename = bin2hex(random_bytes(8)) . "." . $allowed[$info["mime"]];
    if (!move_uploaded_file($file["tmp_name"], __DIR__ . "/../images/" . $filename)) {
        return [null, "Could not save the image. Check the images folder."];
    }
    return [$filename, null];
}

// Deletes an image file from the images/ folder
function delete_product_image($filename)
{
    if ($filename) {
        $path = __DIR__ . "/../images/" . basename($filename);
        if (is_file($path)) {
            unlink($path);
        }
    }
}
