<?php
// Get everything in a customer's cart (with product info)
function load_cart($conn, $userId)
{
    $stmt = $conn->prepare(
        "SELECT c.product_id, c.quantity, p.name, p.price, p.stock, p.image
         FROM cart c
         JOIN products p ON p.id = c.product_id
         WHERE c.user_id = ?
         ORDER BY c.id"
    );
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Draws one chat message bubble (used when a chat page loads).
// The live messages are drawn by js/chat.js with the same look.
function render_chat_message($m, $myId, $viewerRole)
{
    $mine = ((int) $m["sender_id"] === (int) $myId);

    if ($mine) {
        $who = "You";
    } elseif ($m["sender_role"] === "admin" && $viewerRole !== "admin") {
        $who = "ShopConnect Support";
    } else {
        $who = $m["sender_name"];
    }

    echo '<div class="msg ' . ($mine ? "mine" : "theirs") . '" data-id="' . (int) $m["id"] . '">';
    echo '<div class="bubble">';
    echo '<span class="who">' . htmlspecialchars($who) . '</span>';
    echo '<p>' . htmlspecialchars($m["message"]) . '</p>';
    echo '<time>' . date("M d, h:i A", strtotime($m["created_at"])) . '</time>';
    echo '</div></div>';
}
