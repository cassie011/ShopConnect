<?php
require_once "../config/database.php";

// Get the product id from the URL: product.php?id=3
$id = (int) ($_GET["id"] ?? 0);

$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

include "../includes/header.php";
?>

<?php if (!$product): ?>
    <p>Product not found.</p>
    <a class="btn" href="index.php">Back to Shop</a>
<?php else: ?>
    <div class="product-detail">
        <div class="product-image large">
            <?php if (!empty($product["image"])): ?>
                <img src="../images/<?= htmlspecialchars($product["image"]) ?>"
                     alt="<?= htmlspecialchars($product["name"]) ?>">
            <?php else: ?>
                <span>No Image</span>
            <?php endif; ?>
        </div>

        <div class="info">
            <h2><?= htmlspecialchars($product["name"]) ?></h2>
            <p class="price">₱<?= number_format($product["price"], 2) ?></p>
            <p><?= nl2br(htmlspecialchars($product["description"])) ?></p>
            <p><strong>Stock:</strong>
                <?= $product["stock"] > 0 ? $product["stock"] . " available" : "Out of stock" ?>
            </p>

            <?php if ($product["stock"] > 0): ?>
                <form method="POST" action="add-to-cart.php" class="inline-form">
                    <input type="hidden" name="product_id" value="<?= $product["id"] ?>">
                    <input type="number" name="quantity" value="1" min="1"
                           max="<?= $product["stock"] ?>" class="qty-input">
                    <button type="submit" class="btn-secondary">Add to Cart</button>
                </form>
            <?php endif; ?>
            <a class="btn" href="index.php">Back to Shop</a>
        </div>
    </div>
<?php endif; ?>

<?php include "../includes/footer.php"; ?>
