<?php
require_once "../includes/auth.php";
require_once "../config/database.php";
require_once "../includes/functions.php";
require_login();

$userId = $_SESSION["user_id"];

// Handle "update quantity" and "remove" buttons
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = $_POST["action"] ?? "";
    $productId = (int) ($_POST["product_id"] ?? 0);

    if ($action === "update") {
        $quantity = (int) ($_POST["quantity"] ?? 1);
        if ($quantity < 1) {
            $action = "remove";   // quantity 0 means remove
        } else {
            // LEAST(...) stops the quantity from going above the stock
            $stmt = $conn->prepare(
                "UPDATE cart c JOIN products p ON p.id = c.product_id
                 SET c.quantity = LEAST(?, p.stock)
                 WHERE c.user_id = ? AND c.product_id = ?"
            );
            $stmt->bind_param("iii", $quantity, $userId, $productId);
            $stmt->execute();
        }
    }
    if ($action === "remove") {
        $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ? AND product_id = ?");
        $stmt->bind_param("ii", $userId, $productId);
        $stmt->execute();
    }

    header("Location: cart.php");
    exit;
}

$items = load_cart($conn, $userId);
$total = 0;

include "../includes/header.php";
?>

<h2>My Cart</h2>

<?php if (empty($items)): ?>
    <p>Your cart is empty.</p>
    <a class="btn" href="index.php">Continue Shopping</a>
<?php else: ?>
    <table class="table">
        <tr>
            <th>Product</th>
            <th>Price</th>
            <th>Quantity</th>
            <th>Subtotal</th>
            <th></th>
        </tr>
        <?php foreach ($items as $item): ?>
            <?php $subtotal = $item["price"] * $item["quantity"]; $total += $subtotal; ?>
            <tr>
                <td><?= htmlspecialchars($item["name"]) ?></td>
                <td>₱<?= number_format($item["price"], 2) ?></td>
                <td>
                    <form method="POST" action="cart.php" class="inline-form">
                        <input type="hidden" name="action" value="update">
                        <input type="hidden" name="product_id" value="<?= $item["product_id"] ?>">
                        <input type="number" name="quantity" value="<?= $item["quantity"] ?>"
                               min="0" max="<?= $item["stock"] ?>" class="qty-input">
                        <button type="submit">Update</button>
                    </form>
                </td>
                <td>₱<?= number_format($subtotal, 2) ?></td>
                <td>
                    <form method="POST" action="cart.php" class="inline-form">
                        <input type="hidden" name="action" value="remove">
                        <input type="hidden" name="product_id" value="<?= $item["product_id"] ?>">
                        <button type="submit" class="btn-danger">Remove</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
        <tr class="total-row">
            <td colspan="3">Total</td>
            <td colspan="2">₱<?= number_format($total, 2) ?></td>
        </tr>
    </table>

    <a class="btn btn-outline" href="index.php">Continue Shopping</a>
    <a class="btn btn-secondary" href="checkout.php">Checkout</a>
<?php endif; ?>

<?php include "../includes/footer.php"; ?>
