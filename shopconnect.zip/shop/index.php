<?php
require_once "../config/database.php";

// Get the search word (if any) from the URL: index.php?search=mouse
$search = trim($_GET["search"] ?? "");

if ($search !== "") {
    // Prepared statement: safe from SQL injection
    $like = "%" . $search . "%";
    $stmt = $conn->prepare("SELECT * FROM products WHERE name LIKE ? ORDER BY id DESC");
    $stmt->bind_param("s", $like);
} else {
    $stmt = $conn->prepare("SELECT * FROM products ORDER BY id DESC");
}

$stmt->execute();
$result = $stmt->get_result();

include "../includes/header.php";
?>

<?php if ($search === ""): ?>
    <section class="hero">
        <h1>Welcome to ShopConnect 💖</h1>
        <p>Find your favorites and have them delivered to your door.</p>
    </section>
<?php endif; ?>

<form method="GET" action="index.php" class="search-form">
    <input type="text" name="search" placeholder="Search products..."
           value="<?= htmlspecialchars($search) ?>">
    <button type="submit">Search</button>
</form>

<h2>Products</h2>

<?php if ($result->num_rows === 0): ?>
    <p>No products found.</p>
<?php else: ?>
    <div class="product-grid">
        <?php while ($product = $result->fetch_assoc()): ?>
            <div class="product-card">
                <div class="product-image">
                    <?php if (!empty($product["image"])): ?>
                        <img src="../images/<?= htmlspecialchars($product["image"]) ?>"
                             alt="<?= htmlspecialchars($product["name"]) ?>">
                    <?php else: ?>
                        <span>No Image</span>
                    <?php endif; ?>
                </div>
                <h3><?= htmlspecialchars($product["name"]) ?></h3>
                <p class="price">₱<?= number_format($product["price"], 2) ?></p>
                <div class="buttons">
                    <a class="btn" href="product.php?id=<?= $product["id"] ?>">View Product</a>
                    <form method="POST" action="add-to-cart.php" class="inline-form">
                        <input type="hidden" name="product_id" value="<?= $product["id"] ?>">
                        <button type="submit" class="btn-secondary" <?= $product["stock"] < 1 ? "disabled" : "" ?>>
                            <?= $product["stock"] < 1 ? "Out of stock" : "Add to Cart" ?>
                        </button>
                    </form>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
<?php endif; ?>

<?php include "../includes/footer.php"; ?>
