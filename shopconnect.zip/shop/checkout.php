<?php
require_once "../includes/auth.php";
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../email/send-email.php";
require_login();

$userId = $_SESSION["user_id"];

$items = load_cart($conn, $userId);
if (empty($items)) {
    header("Location: cart.php");
    exit;
}

// Pre-fill the form with the user's name and email
$stmt = $conn->prepare("SELECT name, email FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

$errors = [];
$name = $user["name"];
$email = $user["email"];
$address = "";
$phone = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $address = trim($_POST["address"] ?? "");
    $phone = trim($_POST["phone"] ?? "");

    if ($name === "") { $errors[] = "Please enter your name."; }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { $errors[] = "Please enter a valid email."; }
    if ($address === "") { $errors[] = "Please enter your address."; }
    if ($phone === "") { $errors[] = "Please enter your phone number."; }

    if (empty($errors)) {
        // Let MySQL errors become exceptions so we can undo everything if one step fails
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

        try {
            $conn->begin_transaction();

            // 1. Check stock and calculate the total using prices from the database
            $total = 0;
            $prices = [];
            foreach ($items as $item) {
                $stmt = $conn->prepare("SELECT price, stock FROM products WHERE id = ? FOR UPDATE");
                $stmt->bind_param("i", $item["product_id"]);
                $stmt->execute();
                $row = $stmt->get_result()->fetch_assoc();

                if (!$row || $row["stock"] < $item["quantity"]) {
                    throw new Exception("Sorry, there is not enough stock for " . $item["name"] . ".");
                }
                $prices[$item["product_id"]] = $row["price"];
                $total += $row["price"] * $item["quantity"];
            }

            // 2. Save the order as Pending
            $stmt = $conn->prepare(
                "INSERT INTO orders (user_id, customer_name, customer_email, address, phone, total_amount, status)
                 VALUES (?, ?, ?, ?, ?, ?, 'Pending')"
            );
            $stmt->bind_param("issssd", $userId, $name, $email, $address, $phone, $total);
            $stmt->execute();
            $orderId = $conn->insert_id;

            // 3. Save each item and reduce the stock
            foreach ($items as $item) {
                $price = $prices[$item["product_id"]];

                $stmt = $conn->prepare(
                    "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)"
                );
                $stmt->bind_param("iiid", $orderId, $item["product_id"], $item["quantity"], $price);
                $stmt->execute();

                $stmt = $conn->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
                $stmt->bind_param("ii", $item["quantity"], $item["product_id"]);
                $stmt->execute();
            }

            // 4. Empty the cart
            $stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
            $stmt->bind_param("i", $userId);
            $stmt->execute();

            $conn->commit();

            // Send the confirmation email. If it fails, the order is still saved.
            [$sent, $mailError] = send_order_confirmation($orderId, $name, $email, $total);
            $emailStatus = $sent ? "sent" : "failed";

            header("Location: ../orders/orders.php?placed=" . $orderId . "&email=" . $emailStatus);
            exit;

        } catch (mysqli_sql_exception $ex) {
            $conn->rollback();
            $errors[] = "Something went wrong while saving your order. Please try again.";
        } catch (Exception $ex) {
            $conn->rollback();
            $errors[] = $ex->getMessage();
        }

        // Reload the cart so the page shows the latest quantities
        $items = load_cart($conn, $userId);
    }
}

$total = 0;
include "../includes/header.php";
?>

<h2>Checkout</h2>

<?php foreach ($errors as $error): ?>
    <div class="message error"><?= htmlspecialchars($error) ?></div>
<?php endforeach; ?>

<div class="checkout-layout">
    <form method="POST" action="checkout.php" class="form-box">
        <h3>Customer Details</h3>

        <label>Customer Name</label>
        <input type="text" name="name" value="<?= htmlspecialchars($name) ?>" required>

        <label>Email</label>
        <input type="email" name="email" value="<?= htmlspecialchars($email) ?>" required>

        <label>Address</label>
        <input type="text" name="address" value="<?= htmlspecialchars($address) ?>" required>

        <label>Phone Number</label>
        <input type="text" name="phone" value="<?= htmlspecialchars($phone) ?>" required>

        <button type="submit" class="btn-secondary">Place Order</button>
    </form>

    <div class="form-box">
        <h3>Order Summary</h3>
        <table class="table">
            <tr><th>Product</th><th>Qty</th><th>Price</th><th>Subtotal</th></tr>
            <?php foreach ($items as $item): ?>
                <?php $subtotal = $item["price"] * $item["quantity"]; $total += $subtotal; ?>
                <tr>
                    <td><?= htmlspecialchars($item["name"]) ?></td>
                    <td><?= $item["quantity"] ?></td>
                    <td>₱<?= number_format($item["price"], 2) ?></td>
                    <td>₱<?= number_format($subtotal, 2) ?></td>
                </tr>
            <?php endforeach; ?>
            <tr class="total-row">
                <td colspan="3">Total</td>
                <td>₱<?= number_format($total, 2) ?></td>
            </tr>
        </table>
        <p>Payment: not online yet. Your order will be saved as <strong>Pending</strong>.</p>
    </div>
</div>

<?php include "../includes/footer.php"; ?>
