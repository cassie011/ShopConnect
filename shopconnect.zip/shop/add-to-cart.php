<?php
require_once "../includes/auth.php";
require_once "../config/database.php";
require_login();

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit;
}

$userId = $_SESSION["user_id"];
$productId = (int) ($_POST["product_id"] ?? 0);
$quantity = max(1, (int) ($_POST["quantity"] ?? 1));

// Make sure the product exists and get its stock
$stmt = $conn->prepare("SELECT stock FROM products WHERE id = ?");
$stmt->bind_param("i", $productId);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

if ($product && $product["stock"] > 0) {
    $stock = (int) $product["stock"];
    $quantity = min($quantity, $stock);

    // Add to cart. If it is already in the cart, add to the quantity (but never above stock).
    $stmt = $conn->prepare(
        "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)
         ON DUPLICATE KEY UPDATE quantity = LEAST(quantity + ?, ?)"
    );
    $stmt->bind_param("iiiii", $userId, $productId, $quantity, $quantity, $stock);
    $stmt->execute();
}

header("Location: cart.php");
exit;
