// ShopConnect voice & video calls (WebRTC).
//
// How it works:
//  1. The caller clicks a call button. The chat server rings the other person.
//  2. When they accept, the two browsers swap "offer", "answer" and "ICE" messages
//     through the SAME chat connection (this is called signalling).
//  3. After that, audio and video flow directly between the two browsers.

(function () {
    var chat = window.shopChat;
    if (!chat) { return; }

    // A free public STUN server helps browsers find each other.
    var ICE_SERVERS = { iceServers: [{ urls: "stun:stun.l.google.com:19302" }] };
    var RING_TIMEOUT_MS = 45000;   // give up if nobody answers in 45 seconds

    var pc = null;                 // the WebRTC connection
    var localStream = null;        // my microphone / camera
    var remoteStream = null;       // the other person's audio / video
    var call = null;               // { customerId, media, role: "caller"|"callee", name, state }
    var pendingCandidates = [];
    var ringTimer = null, secondsTimer = null, beepTimer = null, toastTimer = null;
    var seconds = 0;
    var audioCtx = null;

    // ---------- Build the call screens (added to the page by JavaScript) ----------
    var holder = document.createElement("div");
    holder.innerHTML =
        '<div class="call-overlay" id="incoming-call" hidden>' +
            '<div class="incoming-card">' +
                '<div class="ring-avatar"><span id="incoming-initial">?</span></div>' +
                '<h3 id="incoming-name">Someone</h3>' +
                '<p id="incoming-type">is calling you...</p>' +
                '<div class="incoming-actions">' +
                    '<button type="button" class="call-pill decline" id="decline-btn">✖ Decline</button>' +
                    '<button type="button" class="call-pill accept" id="accept-btn">📞 Accept</button>' +
                '</div>' +
            '</div>' +
        '</div>' +
        '<div class="call-overlay" id="call-panel" hidden>' +
            '<div class="call-window" id="call-window">' +
                '<div class="call-top"><strong id="call-title">Call</strong><span id="call-status">Calling...</span></div>' +
                '<div class="call-stage">' +
                    '<video id="remote-video" autoplay playsinline></video>' +
                    '<div class="call-avatar"><span id="call-initial">?</span></div>' +
                    '<video id="local-video" autoplay playsinline muted></video>' +
                '</div>' +
                '<div class="call-controls">' +
                    '<button type="button" class="call-pill" id="mute-btn">🎤 Mute</button>' +
                    '<button type="button" class="call-pill" id="camera-btn">📷 Camera off</button>' +
                    '<button type="button" class="call-pill decline" id="end-btn">✖ End Call</button>' +
                '</div>' +
            '</div>' +
        '</div>' +
        '<div class="call-toast" id="call-toast" hidden></div>';
    document.body.appendChild(holder);

    function $(id) { return document.getElementById(id); }

    var incoming = $("incoming-call"), panel = $("call-panel"), callWindow = $("call-window");
    var remoteVideo = $("remote-video"), localVideo = $("local-video");
    var statusEl = $("call-status"), muteBtn = $("mute-btn"), cameraBtn = $("camera-btn");
    var voiceBtn = $("btn-voice-call"), videoBtn = $("btn-video-call");

    // ---------- Small helpers ----------
    function toast(text) {
        var el = $("call-toast");
        el.textContent = text;
        el.hidden = false;
        clearTimeout(toastTimer);
        toastTimer = setTimeout(function () { el.hidden = true; }, 5000);
    }

    function setStatus(text) { statusEl.textContent = text; }

    function stopStream(stream) {
        if (stream) { stream.getTracks().forEach(function (t) { t.stop(); }); }
    }

    function hasTrack(kind) {
        return !!localStream && localStream.getTracks().some(function (t) { return t.kind === kind; });
    }

    function peerName() {
        if (chat.role === "admin") {
            var heading = document.querySelector(".chat-header strong");
            return heading ? heading.textContent : "Customer";
        }
        return "ShopConnect Support";
    }

    function updateButtons() {
        var disabled = !!call || !chat.customerId;
        if (voiceBtn) { voiceBtn.disabled = disabled; }
        if (videoBtn) { videoBtn.disabled = disabled; }
    }

    function mediaErrorText(err) {
        if (err && err.message === "insecure") {
            return "Camera and microphone only work on http://localhost or HTTPS.";
        }
        if (err && err.name === "NotAllowedError") {
            return "Permission blocked. Click the lock icon in the address bar and allow the microphone and camera.";
        }
        if (err && err.name === "NotFoundError") {
            return "No microphone found on this computer.";
        }
        return "Could not start your microphone or camera.";
    }

    // ---------- Ringtone (made with the browser, no sound file needed) ----------
    function beep() {
        try {
            audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
            if (audioCtx.state === "suspended") { audioCtx.resume(); }
            var osc = audioCtx.createOscillator();
            var gain = audioCtx.createGain();
            osc.frequency.value = 880;
            gain.gain.value = 0.08;
            osc.connect(gain);
            gain.connect(audioCtx.destination);
            osc.start();
            osc.stop(audioCtx.currentTime + 0.35);
        } catch (e) { /* no sound is fine */ }
    }
    function startRing() { stopRing(); beep(); beepTimer = setInterval(beep, 1500); }
    function stopRing() { clearInterval(beepTimer); beepTimer = null; }

    // ---------- Microphone and camera ----------
    function getLocalMedia(media) {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            return Promise.reject(new Error("insecure"));
        }
        var wantVideo = (media === "video");
        return navigator.mediaDevices.getUserMedia({ audio: true, video: wantVideo }).catch(function (err) {
            if (wantVideo && err.name !== "NotAllowedError") {
                toast("Camera not available. Continuing with sound only.");
                return navigator.mediaDevices.getUserMedia({ audio: true, video: false });
            }
            throw err;
        });
    }

    function useLocalStream(stream) {
        localStream = stream;
        localVideo.srcObject = stream;
        refreshControls();
    }

    function refreshControls() {
        var audio = hasTrack("audio"), video = hasTrack("video");
        muteBtn.hidden = !audio;
        cameraBtn.hidden = !video;
        localVideo.hidden = !video;
    }

    // ---------- Call screen ----------
    function openCallPanel(statusText) {
        $("call-title").textContent = (call.media === "video" ? "Video call with " : "Voice call with ") + call.name;
        $("call-initial").textContent = call.name.charAt(0).toUpperCase();
        callWindow.className = "call-window " + (call.media === "video" ? "video" : "voice");
        muteBtn.textContent = "🎤 Mute";
        cameraBtn.textContent = "📷 Camera off";
        refreshControls();
        setStatus(statusText);
        panel.hidden = false;
        updateButtons();
    }

    // Clean everything up when a call ends (for any reason)
    function finish(message) {
        clearTimeout(ringTimer);
        clearInterval(secondsTimer);
        stopRing();

        if (pc) {
            pc.onicecandidate = null;
            pc.ontrack = null;
            pc.onconnectionstatechange = null;
            pc.close();
            pc = null;
        }
        stopStream(localStream);
        localStream = null;
        remoteStream = null;
        remoteVideo.srcObject = null;
        localVideo.srcObject = null;
        pendingCandidates = [];
        seconds = 0;
        call = null;

        panel.hidden = true;
        incoming.hidden = true;
        updateButtons();
        if (message) { toast(message); }
    }

    function startTimer() {
        clearInterval(secondsTimer);
        seconds = 0;
        secondsTimer = setInterval(function () {
            seconds++;
            var m = String(Math.floor(seconds / 60)).padStart(2, "0");
            var s = String(seconds % 60).padStart(2, "0");
            setStatus("Connected " + m + ":" + s);
        }, 1000);
    }

    // ---------- WebRTC connection ----------
    function createPeer(addMyTracks) {
        pc = new RTCPeerConnection(chat.iceServers && chat.iceServers.length ? { iceServers: chat.iceServers } : ICE_SERVERS);
        remoteStream = new MediaStream();
        remoteVideo.srcObject = remoteStream;

        pc.onicecandidate = function (event) {
            if (event.candidate && call) {
                chat.send({ type: "rtc_ice", customer_id: call.customerId, candidate: event.candidate });
            }
        };
        pc.ontrack = function (event) {
            remoteStream.addTrack(event.track);
        };
        pc.onconnectionstatechange = function () {
            if (!pc || !call) { return; }
            if (pc.connectionState === "connected") {
                call.state = "active";
                setStatus("Connected 00:00");
                startTimer();
            } else if (pc.connectionState === "disconnected") {
                setStatus("Connection unstable...");
            } else if (pc.connectionState === "failed") {
                chat.send({ type: "call_end", customer_id: call.customerId });
                finish("The connection failed. Please try again.");
            }
        };

        if (addMyTracks) { addLocalTracks(); }
    }

    function addLocalTracks() {
        if (!localStream) { return; }
        localStream.getTracks().forEach(function (track) { pc.addTrack(track, localStream); });
    }

    function flushCandidates() {
        pendingCandidates.forEach(function (c) { pc.addIceCandidate(c).catch(function () {}); });
        pendingCandidates = [];
    }

    // ---------- Starting a call ----------
    function startCall(media) {
        if (call) { return; }
        if (!chat.isReady()) { toast("Not connected to the chat server yet."); return; }
        if (!chat.customerId) { toast("Pick a customer first."); return; }

        call = { customerId: chat.customerId, media: media, role: "caller", name: peerName(), state: "calling" };
        openCallPanel("Starting...");

        getLocalMedia(media).then(function (stream) {
            if (!call) { stopStream(stream); return; }   // cancelled while asking for permission
            useLocalStream(stream);
            setStatus("Calling...");
            chat.send({ type: "call_invite", media: media, to: call.customerId });

            ringTimer = setTimeout(function () {
                if (call && call.state === "calling") {
                    chat.send({ type: "call_end", customer_id: call.customerId });
                    finish("No answer.");
                }
            }, RING_TIMEOUT_MS);
        }).catch(function (err) {
            finish(mediaErrorText(err));
        });
    }

    if (voiceBtn) { voiceBtn.addEventListener("click", function () { startCall("voice"); }); }
    if (videoBtn) { videoBtn.addEventListener("click", function () { startCall("video"); }); }
    updateButtons();

    // ---------- Buttons on the call screen ----------
    $("end-btn").addEventListener("click", function () {
        if (!call) { return; }
        chat.send({ type: "call_end", customer_id: call.customerId });
        finish("Call ended.");
    });

    muteBtn.addEventListener("click", function () {
        if (!localStream) { return; }
        var muted = false;
        localStream.getAudioTracks().forEach(function (t) { t.enabled = !t.enabled; muted = !t.enabled; });
        muteBtn.textContent = muted ? "🔇 Unmute" : "🎤 Mute";
    });

    cameraBtn.addEventListener("click", function () {
        if (!localStream) { return; }
        var off = false;
        localStream.getVideoTracks().forEach(function (t) { t.enabled = !t.enabled; off = !t.enabled; });
        cameraBtn.textContent = off ? "📷 Camera on" : "📷 Camera off";
    });

    // ---------- Someone is calling me ----------
    $("accept-btn").addEventListener("click", function () {
        if (!call || call.role !== "callee") { return; }
        stopRing();
        incoming.hidden = true;
        call.state = "connecting";
        openCallPanel("Connecting...");

        getLocalMedia(call.media).then(function (stream) {
            if (!call) { stopStream(stream); return; }
            useLocalStream(stream);
        }, function (err) {
            toast(mediaErrorText(err) + " You can still listen.");   // join without a microphone
        }).then(function () {
            if (call) { chat.send({ type: "call_accept", customer_id: call.customerId }); }
        });
    });

    $("decline-btn").addEventListener("click", function () {
        if (!call || call.role !== "callee") { return; }
        chat.send({ type: "call_reject", customer_id: call.customerId });
        finish("");
    });

    // ---------- Messages from the chat server ----------
    chat.on("call_invite", function (data) {
        if (call) {   // I am already in a call
            chat.send({ type: "call_reject", customer_id: data.customer_id, reason: "busy" });
            return;
        }
        call = { customerId: data.customer_id, media: data.media, role: "callee", name: data.name, state: "ringing" };
        $("incoming-name").textContent = data.name;
        $("incoming-initial").textContent = data.name.charAt(0).toUpperCase();
        $("incoming-type").textContent = data.media === "video" ? "is video calling you..." : "is calling you...";
        incoming.hidden = false;
        updateButtons();
        startRing();
    });

    // The other person accepted: I (the caller) create the WebRTC offer
    chat.on("call_accept", function () {
        if (!call || call.role !== "caller") { return; }
        clearTimeout(ringTimer);
        call.state = "connecting";
        setStatus("Connecting...");

        createPeer(true);
        // If I have no microphone/camera, I can still receive theirs
        if (!hasTrack("audio")) { pc.addTransceiver("audio", { direction: "recvonly" }); }
        if (call.media === "video" && !hasTrack("video")) { pc.addTransceiver("video", { direction: "recvonly" }); }

        pc.createOffer()
            .then(function (offer) { return pc.setLocalDescription(offer); })
            .then(function () {
                chat.send({ type: "rtc_offer", customer_id: call.customerId, sdp: pc.localDescription });
            })
            .catch(function () { finish("Could not start the call."); });
    });

    // I (the callee) received the offer: send back an answer
    chat.on("rtc_offer", function (data) {
        if (!call || call.role !== "callee") { return; }
        createPeer(false);

        pc.setRemoteDescription(data.sdp)
            .then(function () {
                addLocalTracks();
                flushCandidates();
                return pc.createAnswer();
            })
            .then(function (answer) { return pc.setLocalDescription(answer); })
            .then(function () {
                chat.send({ type: "rtc_answer", customer_id: call.customerId, sdp: pc.localDescription });
            })
            .catch(function () { finish("Could not connect the call."); });
    });

    chat.on("rtc_answer", function (data) {
        if (!pc || !call) { return; }
        pc.setRemoteDescription(data.sdp).then(flushCandidates).catch(function () {
            finish("Could not connect the call.");
        });
    });

    chat.on("rtc_ice", function (data) {
        if (!call || !data.candidate) { return; }
        if (pc && pc.remoteDescription) {
            pc.addIceCandidate(data.candidate).catch(function () {});
        } else {
            pendingCandidates.push(data.candidate);
        }
    });

    chat.on("call_rejected", function (data) {
        if (!call) { return; }
        finish(data.reason === "busy" ? "They are busy right now." : "Call declined.");
    });

    chat.on("call_end", function () {
        if (!call) { return; }
        var wasRinging = (call.state === "ringing");
        finish(wasRinging ? "Missed call." : "The call has ended.");
    });

    chat.on("call_taken", function () {
        if (call && call.role === "callee" && call.state === "ringing") {
            finish("Call answered on another page.");
        }
    });

    chat.on("call_unavailable", function (data) { if (call) { finish(data.message); } });
    chat.on("call_busy", function () { if (call) { finish("A call is already in progress."); } });

    // Closing the page while on a call: tell the other side
    window.addEventListener("beforeunload", function () {
        if (call) { chat.send({ type: "call_end", customer_id: call.customerId }); }
    });
})();
