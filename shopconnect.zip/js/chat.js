// ShopConnect chat (browser side).
// Opens a WebSocket to the chat server, logs in with the ticket,
// and shows messages as they arrive.

(function () {
    var app = document.getElementById("chat-app");
    if (!app) { return; }

    var wsUrl = app.dataset.wsUrl;
    var token = app.dataset.token;
    var role = app.dataset.role;                       // "customer" or "admin"
    var myId = parseInt(app.dataset.me, 10);
    var currentCustomer = parseInt(app.dataset.customer, 10) || 0;
    var iceServers = [];
    try { iceServers = JSON.parse(app.dataset.ice || "[]"); } catch (e) { iceServers = []; }

    var messagesBox = document.getElementById("chat-messages");
    var form = document.getElementById("chat-form");
    var input = document.getElementById("chat-input");
    var statusEl = document.getElementById("chat-status");

    var socket = null;
    var ready = false;
    var giveUp = false;
    var handlers = {};     // other features (voice/video in Stage 7) can listen here

    function setStatus(text, ok) {
        statusEl.textContent = text;
        statusEl.className = "status " + (ok ? "ok" : "bad");
    }

    function scrollToBottom() {
        messagesBox.scrollTop = messagesBox.scrollHeight;
    }

    function formatTime(createdAt) {
        var date = new Date(createdAt.replace(" ", "T"));
        return date.toLocaleString([], { month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit" });
    }

    // Build one message bubble (textContent keeps it safe from HTML tricks)
    function addMessage(data) {
        var empty = document.getElementById("chat-empty");
        if (empty) { empty.remove(); }

        var mine = data.sender_id === myId;
        var who;
        if (mine) { who = "You"; }
        else if (data.sender_role === "admin" && role !== "admin") { who = "ShopConnect Support"; }
        else { who = data.sender_name; }

        var row = document.createElement("div");
        row.className = "msg " + (mine ? "mine" : "theirs");
        row.dataset.id = data.id;

        var bubble = document.createElement("div");
        bubble.className = "bubble";

        var whoEl = document.createElement("span");
        whoEl.className = "who";
        whoEl.textContent = who;

        var text = document.createElement("p");
        text.textContent = data.message;

        var time = document.createElement("time");
        time.textContent = formatTime(data.created_at);

        bubble.appendChild(whoEl);
        bubble.appendChild(text);
        bubble.appendChild(time);
        row.appendChild(bubble);
        messagesBox.appendChild(row);
        scrollToBottom();
    }

    // Admin only: keep the conversation list on the left up to date
    function updateList(data) {
        var list = document.getElementById("chat-list");
        if (!list) { return; }

        var preview = data.message.length > 40 ? data.message.slice(0, 40) + "..." : data.message;
        var item = list.querySelector('.chat-item[data-customer-id="' + data.customer_id + '"]');

        if (!item) {
            // A customer who never chatted before: add them to the top
            var emptyNote = list.querySelector(".chat-list-empty");
            if (emptyNote) { emptyNote.remove(); }

            item = document.createElement("a");
            item.className = "chat-item";
            item.href = "chat.php?customer=" + data.customer_id;
            item.dataset.customerId = data.customer_id;

            var avatar = document.createElement("div");
            avatar.className = "avatar";
            avatar.textContent = data.sender_name.charAt(0).toUpperCase();

            var info = document.createElement("div");
            info.className = "chat-item-info";
            var name = document.createElement("strong");
            name.textContent = data.sender_name;
            var small = document.createElement("small");
            small.className = "chat-preview";
            info.appendChild(name);
            info.appendChild(small);

            var dot = document.createElement("span");
            dot.className = "new-dot";

            item.appendChild(avatar);
            item.appendChild(info);
            item.appendChild(dot);
            list.insertBefore(item, list.querySelector(".start-chat").nextSibling);
        }

        item.querySelector(".chat-preview").textContent = preview;
        if (data.customer_id !== currentCustomer && data.sender_role !== "admin") {
            item.classList.add("unread");
        }
    }

    function dispatch(data) {
        if (data.type === "chat") {
            if (role === "admin") { updateList(data); }
            if (data.customer_id === currentCustomer) { addMessage(data); }
        } else if (data.type === "error") {
            setStatus(data.message, false);
            if (data.fatal) { giveUp = true; }
        }
        if (handlers[data.type]) { handlers[data.type](data); }
    }

    function connect() {
        socket = new WebSocket(wsUrl);

        socket.onopen = function () {
            socket.send(JSON.stringify({ type: "auth", token: token }));
        };

        socket.onmessage = function (event) {
            var data;
            try { data = JSON.parse(event.data); } catch (e) { return; }

            if (data.type === "auth_ok") {
                ready = true;
                setStatus("Connected", true);
            } else {
                dispatch(data);
            }
        };

        socket.onclose = function () {
            ready = false;
            if (giveUp) { return; }
            setStatus("Disconnected. Reconnecting...", false);
            setTimeout(connect, 3000);
        };
    }

    // Send a message when the form is submitted
    form.addEventListener("submit", function (event) {
        event.preventDefault();
        var text = input.value.trim();
        if (text === "") { return; }

        if (!ready) {
            setStatus("Not connected yet. Is the chat server running?", false);
            return;
        }
        socket.send(JSON.stringify({ type: "chat", message: text, to: currentCustomer }));
        input.value = "";
        input.focus();
    });

    // Small helper so Stage 7 (voice/video) can reuse this same connection
    window.shopChat = {
        role: role,
        myId: myId,
        customerId: currentCustomer,
        iceServers: iceServers,
        isReady: function () { return ready; },
        send: function (obj) { if (ready) { socket.send(JSON.stringify(obj)); } },
        on: function (type, fn) { handlers[type] = fn; }
    };

    scrollToBottom();
    connect();
})();
