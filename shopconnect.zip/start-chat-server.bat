@echo off
REM Double-click this file (Windows + XAMPP) to start the ShopConnect chat server.
REM Keep this window open while you use the chat. Press Ctrl+C to stop.
cd /d "%~dp0"
"C:\xampp\php\php.exe" chat\server.php
pause
