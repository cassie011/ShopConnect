<?php
require_once "../includes/auth.php";
require_once "../config/database.php";
require_login();

$stmt = $conn->prepare("SELECT name, email, google_id, password, created_at FROM users WHERE id = ?");
$stmt->bind_param("i", $_SESSION["user_id"]);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

include "../includes/header.php";
?>

<div class="form-box">
    <h2>My Account</h2>
    <p><strong>Name:</strong> <?= htmlspecialchars($user["name"]) ?></p>
    <p><strong>Email:</strong> <?= htmlspecialchars($user["email"]) ?></p>
    <p><strong>Login methods:</strong>
        <?= $user["password"] !== null ? "Email &amp; password" : "" ?>
        <?= ($user["password"] !== null && $user["google_id"] !== null) ? " + " : "" ?>
        <?= $user["google_id"] !== null ? "Google" : "" ?>
    </p>
    <p><strong>Member since:</strong> <?= date("M d, Y", strtotime($user["created_at"])) ?></p>
    <a class="btn btn-outline" href="../orders/orders.php">View My Orders</a>
    <a class="btn btn-outline" href="change-password.php">Change Password</a>
</div>

<?php include "../includes/footer.php"; ?>
