<?php
// Step 1: Send the user to Google's login page.
session_start();
require_once "../config/google.php";
require_once "../includes/url_helper.php";

// "state" is a random code that protects us from fake login requests.
$_SESSION["oauth_state"] = bin2hex(random_bytes(16));

$params = [
    "client_id"     => GOOGLE_CLIENT_ID,
    "redirect_uri"  => google_redirect_uri(),
    "response_type" => "code",
    "scope"         => "openid email profile",   // we only ask for name + email
    "state"         => $_SESSION["oauth_state"],
    "prompt"        => "select_account",
];

header("Location: https://accounts.google.com/o/oauth2/v2/auth?" . http_build_query($params));
exit;
