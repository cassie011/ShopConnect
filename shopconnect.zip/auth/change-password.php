<?php
require_once "../includes/auth.php";
require_once "../config/database.php";
require_login();

$userId = $_SESSION["user_id"];

$stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$hasPassword = $row && $row["password"] !== null;

$errors = [];
$done = false;

if ($hasPassword && $_SERVER["REQUEST_METHOD"] === "POST") {
    $current = $_POST["current_password"] ?? "";
    $new = $_POST["new_password"] ?? "";
    $confirm = $_POST["confirm_password"] ?? "";

    if (!password_verify($current, $row["password"])) {
        $errors[] = "Your current password is wrong.";
    }
    if (strlen($new) < 8) {
        $errors[] = "The new password must be at least 8 characters.";
    }
    if ($new !== $confirm) {
        $errors[] = "The new passwords do not match.";
    }

    if (empty($errors)) {
        $hash = password_hash($new, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->bind_param("si", $hash, $userId);
        $stmt->execute();
        session_regenerate_id(true);
        $done = true;
    }
}

include "../includes/header.php";
?>

<div class="form-box">
    <h2>Change Password</h2>

    <?php if (!$hasPassword): ?>
        <p>Your account uses Google login, so it has no password to change.</p>
    <?php else: ?>
        <?php if ($done): ?>
            <div class="message success">Your password was changed.</div>
        <?php endif; ?>
        <?php foreach ($errors as $error): ?>
            <div class="message error"><?= htmlspecialchars($error) ?></div>
        <?php endforeach; ?>

        <form method="POST" action="change-password.php">
            <label>Current Password</label>
            <input type="password" name="current_password" required>

            <label>New Password (at least 8 characters)</label>
            <input type="password" name="new_password" required>

            <label>Confirm New Password</label>
            <input type="password" name="confirm_password" required>

            <button type="submit">Change Password</button>
        </form>
    <?php endif; ?>

    <a class="btn btn-outline" href="account.php">Back to My Account</a>
</div>

<?php include "../includes/footer.php"; ?>
