<?php
// Step 2: Google sends the user back here with a "code".
// We trade the code for an access token, then ask Google who the user is.
session_start();
require_once "../config/database.php";
require_once "../config/google.php";
require_once "../includes/url_helper.php";
require_once "../email/send-email.php";

// Small helper: send a request with cURL and return the JSON as an array
function google_request($url, $postData = null, $accessToken = null)
{
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 15);

    if ($postData !== null) {
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));
    }
    if ($accessToken !== null) {
        curl_setopt($ch, CURLOPT_HTTPHEADER, ["Authorization: Bearer " . $accessToken]);
    }

    $response = curl_exec($ch);
    if ($response === false) {
        $message = curl_error($ch);
        curl_close($ch);
        die("Could not contact Google: " . htmlspecialchars($message) .
            "<br>If this says 'SSL certificate problem', see the Troubleshooting section of the Stage 3 guide.");
    }
    curl_close($ch);

    return json_decode($response, true);
}

function fail_and_go_back()
{
    header("Location: login.php?error=google");
    exit;
}

// 1. Did the user cancel, or did Google report an error?
if (isset($_GET["error"]) || !isset($_GET["code"])) {
    fail_and_go_back();
}

// 2. Check the "state" code matches the one we created
if (!isset($_SESSION["oauth_state"]) || !hash_equals($_SESSION["oauth_state"], $_GET["state"] ?? "")) {
    fail_and_go_back();
}
unset($_SESSION["oauth_state"]);

// 3. Trade the code for an access token
$token = google_request("https://oauth2.googleapis.com/token", [
    "code"          => $_GET["code"],
    "client_id"     => GOOGLE_CLIENT_ID,
    "client_secret" => GOOGLE_CLIENT_SECRET,
    "redirect_uri"  => google_redirect_uri(),
    "grant_type"    => "authorization_code",
]);

if (empty($token["access_token"])) {
    fail_and_go_back();
}

// 4. Ask Google for the user's profile (Google ID, name, email)
$profile = google_request("https://www.googleapis.com/oauth2/v3/userinfo", null, $token["access_token"]);

$googleId = $profile["sub"] ?? "";
$name     = $profile["name"] ?? "";
$email    = $profile["email"] ?? "";
$verified = $profile["email_verified"] ?? false;

if ($googleId === "" || $email === "" || !$verified) {
    fail_and_go_back();
}
if ($name === "") {
    $name = $email;
}

// 5. Find or create the user in MySQL
// (a) Has this Google account logged in before?
$stmt = $conn->prepare("SELECT id, name, role FROM users WHERE google_id = ?");
$stmt->bind_param("s", $googleId);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    // (b) Is there already a normal account with the same email? Link Google to it.
    $stmt = $conn->prepare("SELECT id, name, role FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if ($user) {
        $stmt = $conn->prepare("UPDATE users SET google_id = ? WHERE id = ?");
        $stmt->bind_param("si", $googleId, $user["id"]);
        $stmt->execute();
    } else {
        // (c) Brand new user. The password stays NULL (Google users have no password here).
        $stmt = $conn->prepare("INSERT INTO users (google_id, name, email, password) VALUES (?, ?, ?, NULL)");
        $stmt->bind_param("sss", $googleId, $name, $email);
        $stmt->execute();
        $user = ["id" => $conn->insert_id, "name" => $name, "role" => "customer"];
        send_welcome_email($name, $email);   // if this fails, login still works
    }
}

// 6. Log the user in with a session, then go to the shop
session_regenerate_id(true);
$_SESSION["user_id"] = $user["id"];
$_SESSION["user_name"] = $user["name"];
$_SESSION["role"] = $user["role"];

if ($user["role"] === "admin") {
    header("Location: ../admin/dashboard.php");
} else {
    header("Location: ../shop/index.php");
}
exit;
