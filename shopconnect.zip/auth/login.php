<?php
session_start();
require_once "../config/database.php";

// Already logged in? Go to the shop.
if (isset($_SESSION["user_id"])) {
    header("Location: ../shop/index.php");
    exit;
}

$error = "";
$email = "";

if (isset($_GET["error"])) {
    $error = "Google login failed. Please try again.";
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    // Find the user by email (prepared statement)
    $stmt = $conn->prepare("SELECT id, name, password, role FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if (!$user) {
        $error = "Wrong email or password.";
    } elseif ($user["password"] === null) {
        // Google-only accounts (Stage 3) have no password
        $error = "This account has no password. Please use Login with Google.";
    } elseif (!password_verify($password, $user["password"])) {
        $error = "Wrong email or password.";
    } else {
        // Success: remember the user in the session
        session_regenerate_id(true);
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["user_name"] = $user["name"];
        $_SESSION["role"] = $user["role"];

        // Admins go to the admin panel, customers go to the shop
        if ($user["role"] === "admin") {
            header("Location: ../admin/dashboard.php");
        } else {
            header("Location: ../shop/index.php");
        }
        exit;
    }
}

include "../includes/header.php";
?>

<div class="form-box">
    <img class="form-logo" src="<?= $base ?>/assets/shopconnect-logo.png" alt="ShopConnect">
    <h2>Login</h2>

    <?php if (isset($_GET["registered"])): ?>
        <div class="message success">Account created! You can now login.</div>
    <?php endif; ?>
    <?php if (isset($_GET["loggedout"])): ?>
        <div class="message success">You have been logged out.</div>
    <?php endif; ?>
    <?php if ($error !== ""): ?>
        <div class="message error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="login.php">
        <label>Email</label>
        <input type="email" name="email" value="<?= htmlspecialchars($email) ?>" required>

        <label>Password</label>
        <input type="password" name="password" required>

        <button type="submit">Login</button>
    </form>

    <a class="btn btn-google" href="google-login.php">Login with Google</a>
    <a class="btn btn-outline" href="register.php">Create Account</a>
</div>

<?php include "../includes/footer.php"; ?>
