<?php
session_start();
require_once "../config/database.php";
require_once "../email/send-email.php";

$errors = [];
$name = "";
$email = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";
    $confirm = $_POST["confirm_password"] ?? "";

    // 1. Check the form
    if ($name === "") {
        $errors[] = "Please enter your name.";
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Please enter a valid email address.";
    }
    if (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters.";
    }
    if ($password !== $confirm) {
        $errors[] = "Passwords do not match.";
    }

    // 2. Check if the email is already used
    if (empty($errors)) {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            $errors[] = "That email is already registered. Please login.";
        }
    }

    // 3. Save the user (password is hashed, never saved as plain text)
    if (empty($errors)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $name, $email, $hash);
        $stmt->execute();

        send_welcome_email($name, $email);   // if this fails, registration still works

        header("Location: login.php?registered=1");
        exit;
    }
}

include "../includes/header.php";
?>

<div class="form-box">
    <img class="form-logo" src="<?= $base ?>/assets/shopconnect-logo.png" alt="ShopConnect">
    <h2>Create Account</h2>

    <?php foreach ($errors as $error): ?>
        <div class="message error"><?= htmlspecialchars($error) ?></div>
    <?php endforeach; ?>

    <form method="POST" action="register.php">
        <label>Name</label>
        <input type="text" name="name" value="<?= htmlspecialchars($name) ?>" required>

        <label>Email</label>
        <input type="email" name="email" value="<?= htmlspecialchars($email) ?>" required>

        <label>Password</label>
        <input type="password" name="password" required>

        <label>Confirm Password</label>
        <input type="password" name="confirm_password" required>

        <button type="submit">Create Account</button>
        <a class="btn btn-outline" href="login.php">I already have an account</a>
    </form>
</div>

<?php include "../includes/footer.php"; ?>
