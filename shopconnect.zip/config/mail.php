<?php
// Gmail SMTP settings.
//
// IMPORTANT: Do NOT put your normal Gmail password here!
// Use a Google "App Password" (16 letters). See the Stage 5 guide.
// An App Password can be deleted anytime in your Google account, so it is safer.
// Never share this file, post it online, or put it in a screenshot.

define("MAIL_USERNAME", "cassandraquintua11@gmail.com");          // your Gmail address
define("MAIL_APP_PASSWORD", "zaxegybbyuhqmwmr");       // the 16-letter App Password
define("MAIL_FROM_NAME", "ShopConnect");
