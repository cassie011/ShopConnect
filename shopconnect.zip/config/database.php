<?php
// Database settings (XAMPP defaults)
$host = "localhost";
$user = "root";
$pass = "";            // XAMPP's default MySQL password is empty
$dbname = "shopconnect";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");
