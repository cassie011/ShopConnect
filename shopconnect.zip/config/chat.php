<?php
// Chat settings.

// The port the chat server listens on. Change it if you see "address already in use".
define("CHAT_PORT", 8080);

// The address the browser uses to reach the chat server.
// (If you change CHAT_PORT above, change it here too.)
define("CHAT_WS_URL", "ws://localhost:8080");

// Secret text used to sign chat login tickets. Keep it private.
// (A random one was made for you. You may change it, then restart the chat server.)
define("CHAT_SECRET", "3a6efaed2b682ee7478bd334667258b91472be7efdd49f14");
