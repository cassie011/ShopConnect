<?php
// Google OAuth settings.
// Paste the values from Google Cloud Console (see the Stage 3 guide).
// Never share this file or upload it to GitHub: it contains a secret.

define("GOOGLE_CLIENT_ID", "201856365045-glkrjagn0v47p1baavvj6vpb99aurs34.apps.googleusercontent.com");
define("GOOGLE_CLIENT_SECRET", "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");

// Must match EXACTLY what you typed in Google Cloud Console
define("GOOGLE_REDIRECT_URI", "http://localhost/shopconnect/auth/google-callback.php");
