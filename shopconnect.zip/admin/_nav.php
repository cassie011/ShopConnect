<div class="admin-nav">
    <a href="dashboard.php">Dashboard</a>
    <a href="products.php">Products</a>
    <a href="add-product.php">Add Product</a>
    <a href="orders.php">Orders</a>
    <a href="chat.php">Chats</a>
    <a href="email-customer.php">Send Email</a>
</div>
