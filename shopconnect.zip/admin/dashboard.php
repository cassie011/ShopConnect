<?php
require_once "../includes/auth.php";
require_once "../config/database.php";
require_admin();

// These queries have no user input, so plain query() is safe here
$products  = $conn->query("SELECT COUNT(*) AS c FROM products")->fetch_assoc()["c"];
$customers = $conn->query("SELECT COUNT(*) AS c FROM users WHERE role = 'customer'")->fetch_assoc()["c"];
$orders    = $conn->query("SELECT COUNT(*) AS c FROM orders")->fetch_assoc()["c"];
$pending   = $conn->query("SELECT COUNT(*) AS c FROM orders WHERE status = 'Pending'")->fetch_assoc()["c"];

include "../includes/header.php";
include "_nav.php";
?>

<h2>Admin Dashboard</h2>

<div class="stats">
    <div class="stat"><span><?= $products ?></span>Products</div>
    <div class="stat"><span><?= $customers ?></span>Customers</div>
    <div class="stat"><span><?= $orders ?></span>Orders</div>
    <div class="stat"><span><?= $pending ?></span>Pending Orders</div>
</div>

<?php include "../includes/footer.php"; ?>
