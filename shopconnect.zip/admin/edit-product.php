<?php
require_once "../includes/auth.php";
require_once "../config/database.php";
require_once "../includes/upload.php";
require_admin();

$id = (int) ($_GET["id"] ?? 0);

$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

$errors = [];

if ($product && $_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $description = trim($_POST["description"] ?? "");
    $price = trim($_POST["price"] ?? "");
    $stock = trim($_POST["stock"] ?? "");

    if ($name === "") { $errors[] = "Please enter a product name."; }
    if (!is_numeric($price) || $price < 0) { $errors[] = "Price must be a number (0 or more)."; }
    if (!ctype_digit($stock)) { $errors[] = "Stock must be a whole number (0 or more)."; }

    [$newImage, $imageError] = save_product_image($_FILES["image"] ?? null);
    if ($imageError) { $errors[] = $imageError; }

    if (empty($errors)) {
        $priceNumber = (float) $price;
        $stockNumber = (int) $stock;
        $imageToSave = $newImage ?? $product["image"];   // keep the old image if no new one

        $stmt = $conn->prepare("UPDATE products SET name = ?, description = ?, price = ?, image = ?, stock = ? WHERE id = ?");
        $stmt->bind_param("ssdsii", $name, $description, $priceNumber, $imageToSave, $stockNumber, $id);
        $stmt->execute();

        if ($newImage) { delete_product_image($product["image"]); }

        header("Location: products.php");
        exit;
    }
    if ($newImage) { delete_product_image($newImage); }

    // Show what the admin typed
    $product["name"] = $name;
    $product["description"] = $description;
    $product["price"] = $price;
    $product["stock"] = $stock;
}

include "../includes/header.php";
include "_nav.php";
?>

<?php if (!$product): ?>
    <p>Product not found.</p>
<?php else: ?>
    <div class="form-box wide">
        <h2>Edit Product</h2>

        <?php foreach ($errors as $error): ?>
            <div class="message error"><?= htmlspecialchars($error) ?></div>
        <?php endforeach; ?>

        <form method="POST" action="edit-product.php?id=<?= $id ?>" enctype="multipart/form-data">
            <label>Name</label>
            <input type="text" name="name" value="<?= htmlspecialchars($product["name"]) ?>" required>

            <label>Description</label>
            <textarea name="description" rows="4"><?= htmlspecialchars($product["description"]) ?></textarea>

            <label>Price (₱)</label>
            <input type="text" name="price" value="<?= htmlspecialchars($product["price"]) ?>" required>

            <label>Stock</label>
            <input type="text" name="stock" value="<?= htmlspecialchars($product["stock"]) ?>" required>

            <label>Image</label>
            <?php if ($product["image"]): ?>
                <p><img class="thumb" src="../images/<?= htmlspecialchars($product["image"]) ?>" alt=""></p>
            <?php endif; ?>
            <input type="file" name="image" accept="image/*">
            <small class="muted">Choose a file only if you want to replace the image.</small>

            <button type="submit" class="btn-secondary">Save Changes</button>
        </form>
    </div>
<?php endif; ?>

<?php include "../includes/footer.php"; ?>
