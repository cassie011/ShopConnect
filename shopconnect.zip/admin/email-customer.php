<?php
require_once "../includes/auth.php";
require_once "../config/database.php";
require_once "../email/send-email.php";
require_admin();

$to = trim($_GET["to"] ?? "");
$subject = "";
$message = "";
$result = "";
$resultType = "";

// Coming from the Orders page: pre-fill the customer's email and a subject
if (isset($_GET["order"])) {
    $orderId = (int) $_GET["order"];
    $stmt = $conn->prepare("SELECT customer_email FROM orders WHERE id = ?");
    $stmt->bind_param("i", $orderId);
    $stmt->execute();
    $order = $stmt->get_result()->fetch_assoc();
    if ($order) {
        $to = $order["customer_email"];
        $subject = "About your ShopConnect order #" . $orderId;
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $to = trim($_POST["to"] ?? "");
    $subject = trim($_POST["subject"] ?? "");
    $message = trim($_POST["message"] ?? "");

    if (!filter_var($to, FILTER_VALIDATE_EMAIL) || $subject === "" || $message === "") {
        $result = "Please fill in a valid email, a subject, and a message.";
        $resultType = "error";
    } else {
        // Use the customer's name if we know it
        $stmt = $conn->prepare("SELECT name FROM users WHERE email = ?");
        $stmt->bind_param("s", $to);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $toName = $user["name"] ?? "";

        $body = $message . "\n\nShopConnect";
        [$sent, $error] = send_mail($to, $toName, $subject, $body);

        if ($sent) {
            $result = "Email sent to " . $to . ".";
            $resultType = "success";
            $subject = "";
            $message = "";
        } else {
            $result = "Email could not be sent: " . $error;
            $resultType = "error";
        }
    }
}

// Customer list for the suggestions box
$customers = $conn->query("SELECT name, email FROM users WHERE role = 'customer' ORDER BY name")->fetch_all(MYSQLI_ASSOC);

include "../includes/header.php";
include "_nav.php";
?>

<div class="form-box wide">
    <h2>Send Email to Customer</h2>

    <?php if ($result): ?>
        <div class="message <?= $resultType ?>"><?= htmlspecialchars($result) ?></div>
    <?php endif; ?>

    <form method="POST" action="email-customer.php">
        <label>To (customer email)</label>
        <input type="email" name="to" list="customer-list" value="<?= htmlspecialchars($to) ?>" required>
        <datalist id="customer-list">
            <?php foreach ($customers as $c): ?>
                <option value="<?= htmlspecialchars($c["email"]) ?>"><?= htmlspecialchars($c["name"]) ?></option>
            <?php endforeach; ?>
        </datalist>

        <label>Subject</label>
        <input type="text" name="subject" value="<?= htmlspecialchars($subject) ?>" required>

        <label>Message</label>
        <textarea name="message" rows="6" required><?= htmlspecialchars($message) ?></textarea>

        <button type="submit" class="btn-secondary">Send Email</button>
    </form>
</div>

<?php include "../includes/footer.php"; ?>
