<?php
require_once "../includes/auth.php";
require_once "../config/database.php";
require_once "../includes/functions.php";
require_once "../includes/chat_token.php";
require_admin();

$adminId = $_SESSION["user_id"];
$selected = (int) ($_GET["customer"] ?? 0);

// Customers who have chatted, newest conversation first
$conversations = $conn->query(
    "SELECT u.id, u.name, u.email, MAX(m.id) AS last_id
     FROM users u JOIN messages m ON (m.sender_id = u.id OR m.receiver_id = u.id)
     WHERE u.role = 'customer'
     GROUP BY u.id, u.name, u.email
     ORDER BY last_id DESC"
)->fetch_all(MYSQLI_ASSOC);

// Add a short preview of the last message to each conversation
foreach ($conversations as &$c) {
    $stmt = $conn->prepare("SELECT message FROM messages WHERE id = ?");
    $stmt->bind_param("i", $c["last_id"]);
    $stmt->execute();
    $c["preview"] = mb_strimwidth($stmt->get_result()->fetch_assoc()["message"], 0, 40, "...");
}
unset($c);

// All customers (for "start a new chat")
$allCustomers = $conn->query("SELECT id, name FROM users WHERE role = 'customer' ORDER BY name")->fetch_all(MYSQLI_ASSOC);

// The customer whose conversation is open
$customer = null;
$messages = [];
if ($selected > 0) {
    $stmt = $conn->prepare("SELECT id, name, email FROM users WHERE id = ? AND role = 'customer'");
    $stmt->bind_param("i", $selected);
    $stmt->execute();
    $customer = $stmt->get_result()->fetch_assoc();
}
if ($customer) {
    $stmt = $conn->prepare(
        "SELECT m.id, m.sender_id, m.message, m.created_at, u.name AS sender_name, u.role AS sender_role
         FROM messages m JOIN users u ON u.id = m.sender_id
         WHERE m.sender_id = ? OR m.receiver_id = ?
         ORDER BY m.id DESC LIMIT 200"
    );
    $stmt->bind_param("ii", $customer["id"], $customer["id"]);
    $stmt->execute();
    $messages = array_reverse($stmt->get_result()->fetch_all(MYSQLI_ASSOC));
}

$token = make_chat_token($adminId, $_SESSION["user_name"], "admin");

include "../includes/header.php";
include "_nav.php";
?>

<h2>Customer Chats</h2>

<div class="chat-layout">

    <aside class="chat-list" id="chat-list">
        <form method="GET" action="chat.php" class="start-chat">
            <select name="customer" onchange="this.form.submit()">
                <option value="">+ Start a chat with...</option>
                <?php foreach ($allCustomers as $c): ?>
                    <option value="<?= $c["id"] ?>"><?= htmlspecialchars($c["name"]) ?></option>
                <?php endforeach; ?>
            </select>
        </form>

        <?php if (empty($conversations)): ?>
            <p class="muted chat-list-empty">No customer messages yet.</p>
        <?php endif; ?>

        <?php foreach ($conversations as $c): ?>
            <a class="chat-item <?= $c["id"] === $selected ? "active" : "" ?>"
               href="chat.php?customer=<?= $c["id"] ?>" data-customer-id="<?= $c["id"] ?>">
                <div class="avatar"><?= htmlspecialchars(strtoupper(mb_substr($c["name"], 0, 1))) ?></div>
                <div class="chat-item-info">
                    <strong><?= htmlspecialchars($c["name"]) ?></strong>
                    <small class="chat-preview"><?= htmlspecialchars($c["preview"]) ?></small>
                </div>
                <span class="new-dot"></span>
            </a>
        <?php endforeach; ?>
    </aside>

    <div class="chat-card" id="chat-app"
         data-ws-url="<?= htmlspecialchars(chat_ws_url()) ?>"
     data-ice="<?= htmlspecialchars(json_encode(chat_ice_servers())) ?>"
         data-token="<?= htmlspecialchars($token) ?>"
         data-role="admin"
         data-me="<?= (int) $adminId ?>"
         data-customer="<?= $customer ? (int) $customer["id"] : 0 ?>">

        <div class="chat-header">
            <div class="avatar"><?= $customer ? htmlspecialchars(strtoupper(mb_substr($customer["name"], 0, 1))) : "💬" ?></div>
            <div>
                <strong><?= $customer ? htmlspecialchars($customer["name"]) : "No conversation selected" ?></strong>
                <?php if ($customer): ?>
                    <small class="muted">(<?= htmlspecialchars($customer["email"]) ?>)</small>
                <?php endif; ?>
                <br><small id="chat-status" class="status">Connecting...</small>
            </div>
            <div class="call-buttons">
            <button type="button" id="btn-voice-call" <?= $customer ? "" : "disabled" ?>>📞 Voice Call</button>
            <button type="button" id="btn-video-call" <?= $customer ? "" : "disabled" ?>>🎥 Video Call</button>
        </div>
        </div>

        <div class="chat-messages" id="chat-messages">
            <?php if (!$customer): ?>
                <p class="chat-empty" id="chat-empty">Pick a conversation on the left to start chatting.</p>
            <?php elseif (empty($messages)): ?>
                <p class="chat-empty" id="chat-empty">No messages yet. Write the first one!</p>
            <?php endif; ?>
            <?php foreach ($messages as $m) { render_chat_message($m, $adminId, "admin"); } ?>
        </div>

        <form id="chat-form" class="chat-form" autocomplete="off">
            <input type="text" id="chat-input" placeholder="Type your reply..." maxlength="1000"
                   <?= $customer ? "" : "disabled" ?>>
            <button type="submit" <?= $customer ? "" : "disabled" ?>>Send</button>
        </form>
    </div>
</div>

<script src="<?= $base ?>/js/chat.js"></script>
<script src="<?= $base ?>/js/call.js"></script>

<?php include "../includes/footer.php"; ?>
