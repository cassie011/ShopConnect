<?php
// RUN THIS FILE ONCE to create the admin account, then DELETE IT.
// Change the details below first if you want.
$adminName = "Shop Admin";
$adminEmail = "admin@shopconnect.com";
$adminPassword = "admin123";

require_once "../config/database.php";

$stmt = $conn->prepare("SELECT id FROM users WHERE role = 'admin' LIMIT 1");
$stmt->execute();

if ($stmt->get_result()->num_rows > 0) {
    die("An admin account already exists. Delete this file (admin/setup-admin.php).");
}

$hash = password_hash($adminPassword, PASSWORD_DEFAULT);

// If this email already has a normal account, turn it into the admin account
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $adminEmail);
$stmt->execute();
$existing = $stmt->get_result()->fetch_assoc();

if ($existing) {
    $stmt = $conn->prepare("UPDATE users SET role = 'admin', password = ? WHERE id = ?");
    $stmt->bind_param("si", $hash, $existing["id"]);
} else {
    $stmt = $conn->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'admin')");
    $stmt->bind_param("sss", $adminName, $adminEmail, $hash);
}
$stmt->execute();

echo "Admin created!<br>Email: " . htmlspecialchars($adminEmail) .
     "<br>Password: " . htmlspecialchars($adminPassword) .
     "<br><br><strong>Now DELETE the file admin/setup-admin.php.</strong> " .
     "<a href='../auth/login.php'>Go to login</a>";
