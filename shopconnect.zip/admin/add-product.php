<?php
require_once "../includes/auth.php";
require_once "../config/database.php";
require_once "../includes/upload.php";
require_admin();

$errors = [];
$name = $description = $price = $stock = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"] ?? "");
    $description = trim($_POST["description"] ?? "");
    $price = trim($_POST["price"] ?? "");
    $stock = trim($_POST["stock"] ?? "");

    if ($name === "") { $errors[] = "Please enter a product name."; }
    if (!is_numeric($price) || $price < 0) { $errors[] = "Price must be a number (0 or more)."; }
    if (!ctype_digit($stock)) { $errors[] = "Stock must be a whole number (0 or more)."; }

    [$image, $imageError] = save_product_image($_FILES["image"] ?? null);
    if ($imageError) { $errors[] = $imageError; }

    if (empty($errors)) {
        $priceNumber = (float) $price;
        $stockNumber = (int) $stock;

        $stmt = $conn->prepare("INSERT INTO products (name, description, price, image, stock) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssdsi", $name, $description, $priceNumber, $image, $stockNumber);
        $stmt->execute();

        header("Location: products.php");
        exit;
    }
    // If something failed, remove the image we just saved
    if ($image) { delete_product_image($image); }
}

include "../includes/header.php";
include "_nav.php";
?>

<div class="form-box wide">
    <h2>Add Product</h2>

    <?php foreach ($errors as $error): ?>
        <div class="message error"><?= htmlspecialchars($error) ?></div>
    <?php endforeach; ?>

    <form method="POST" action="add-product.php" enctype="multipart/form-data">
        <label>Name</label>
        <input type="text" name="name" value="<?= htmlspecialchars($name) ?>" required>

        <label>Description</label>
        <textarea name="description" rows="4"><?= htmlspecialchars($description) ?></textarea>

        <label>Price (₱)</label>
        <input type="text" name="price" value="<?= htmlspecialchars($price) ?>" required>

        <label>Stock</label>
        <input type="text" name="stock" value="<?= htmlspecialchars($stock) ?>" required>

        <label>Image (JPG, PNG, GIF or WEBP, max 2 MB)</label>
        <input type="file" name="image" accept="image/*">

        <button type="submit" class="btn-secondary">Save Product</button>
    </form>
</div>

<?php include "../includes/footer.php"; ?>
