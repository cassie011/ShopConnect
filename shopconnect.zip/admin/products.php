<?php
require_once "../includes/auth.php";
require_once "../config/database.php";
require_once "../includes/upload.php";
require_admin();

$message = "";
$error = "";

// Delete a product
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["delete_id"])) {
    $deleteId = (int) $_POST["delete_id"];
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    try {
        $stmt = $conn->prepare("SELECT image FROM products WHERE id = ?");
        $stmt->bind_param("i", $deleteId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();

        $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        $stmt->bind_param("i", $deleteId);
        $stmt->execute();

        if ($row) {
            delete_product_image($row["image"]);
        }
        $message = "Product deleted.";
    } catch (mysqli_sql_exception $e) {
        // A product that is inside an old order cannot be deleted
        $error = "This product is part of an existing order, so it cannot be deleted. Set its stock to 0 instead.";
    }
}

$result = $conn->query("SELECT * FROM products ORDER BY id DESC");

include "../includes/header.php";
include "_nav.php";
?>

<h2>Products</h2>

<?php if ($message): ?><div class="message success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if ($error): ?><div class="message error"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<a class="btn btn-secondary" href="add-product.php">+ Add Product</a>

<table class="table">
    <tr><th>Image</th><th>Name</th><th>Price</th><th>Stock</th><th>Actions</th></tr>
    <?php while ($p = $result->fetch_assoc()): ?>
        <tr>
            <td>
                <?php if ($p["image"]): ?>
                    <img class="thumb" src="../images/<?= htmlspecialchars($p["image"]) ?>" alt="">
                <?php else: ?>
                    <span class="muted">none</span>
                <?php endif; ?>
            </td>
            <td><?= htmlspecialchars($p["name"]) ?></td>
            <td>₱<?= number_format($p["price"], 2) ?></td>
            <td><?= $p["stock"] ?></td>
            <td>
                <a class="btn" href="edit-product.php?id=<?= $p["id"] ?>">Edit</a>
                <form method="POST" action="products.php" class="inline-form"
                      onsubmit="return confirm('Delete this product?');">
                    <input type="hidden" name="delete_id" value="<?= $p["id"] ?>">
                    <button type="submit" class="btn-danger">Delete</button>
                </form>
            </td>
        </tr>
    <?php endwhile; ?>
</table>

<?php include "../includes/footer.php"; ?>
