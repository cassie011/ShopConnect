<?php
require_once "../includes/auth.php";
require_once "../config/database.php";
require_admin();

$statuses = ["Pending", "Processing", "Shipped", "Completed", "Cancelled"];
$message = "";

// Change an order's status
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $orderId = (int) ($_POST["order_id"] ?? 0);
    $status = $_POST["status"] ?? "";

    if (in_array($status, $statuses, true)) {
        $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $orderId);
        $stmt->execute();
        $message = "Order #" . $orderId . " is now " . $status . ".";
    }
}

$orders = $conn->query("SELECT * FROM orders ORDER BY id DESC")->fetch_all(MYSQLI_ASSOC);

include "../includes/header.php";
include "_nav.php";
?>

<h2>Customer Orders</h2>

<?php if ($message): ?><div class="message success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
<?php if (empty($orders)): ?><p>No orders yet.</p><?php endif; ?>

<?php foreach ($orders as $order): ?>
    <?php
    $stmt = $conn->prepare(
        "SELECT oi.quantity, oi.price, p.name
         FROM order_items oi JOIN products p ON p.id = oi.product_id
         WHERE oi.order_id = ?"
    );
    $stmt->bind_param("i", $order["id"]);
    $stmt->execute();
    $orderItems = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    ?>
    <div class="order-card">
        <div class="order-head">
            <strong>Order #<?= $order["id"] ?></strong>
            <span class="badge badge-<?= strtolower($order["status"]) ?>"><?= $order["status"] ?></span>
            <span class="muted"><?= date("M d, Y h:i A", strtotime($order["created_at"])) ?></span>
        </div>

        <p>
            <strong><?= htmlspecialchars($order["customer_name"]) ?></strong>
            (<?= htmlspecialchars($order["customer_email"]) ?>)<br>
            <?= htmlspecialchars($order["address"]) ?> | <?= htmlspecialchars($order["phone"]) ?>
        </p>

        <table class="table">
            <tr><th>Product</th><th>Qty</th><th>Price</th><th>Subtotal</th></tr>
            <?php foreach ($orderItems as $item): ?>
                <tr>
                    <td><?= htmlspecialchars($item["name"]) ?></td>
                    <td><?= $item["quantity"] ?></td>
                    <td>₱<?= number_format($item["price"], 2) ?></td>
                    <td>₱<?= number_format($item["price"] * $item["quantity"], 2) ?></td>
                </tr>
            <?php endforeach; ?>
            <tr class="total-row">
                <td colspan="3">Total</td>
                <td>₱<?= number_format($order["total_amount"], 2) ?></td>
            </tr>
        </table>

        <form method="POST" action="orders.php" class="inline-form">
            <input type="hidden" name="order_id" value="<?= $order["id"] ?>">
            <select name="status">
                <?php foreach ($statuses as $s): ?>
                    <option value="<?= $s ?>" <?= $s === $order["status"] ? "selected" : "" ?>><?= $s ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Change Status</button>
        </form>
        <a class="btn btn-outline" href="email-customer.php?order=<?= $order["id"] ?>">Email Customer</a>
    </div>
<?php endforeach; ?>

<?php include "../includes/footer.php"; ?>
