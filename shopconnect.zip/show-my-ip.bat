@echo off
REM Shows your computer's Wi-Fi address (look for "IPv4 Address", like 192.168.1.5)
ipconfig | findstr /i "IPv4"
echo.
echo On your phone, open:  http://YOUR-IPV4-ADDRESS/shopconnect/
pause
